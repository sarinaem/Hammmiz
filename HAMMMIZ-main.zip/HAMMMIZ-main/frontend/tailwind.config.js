/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      
      keyframes: {
        rotateCircle: {
          '0%': { transform: 'translate(-50%, -50%) rotate(0deg)' },
          
          '100%': { transform: 'translate(-50%, -50%) rotate(360deg)' },
        },
      },
      backgroundImage: {
        'gray-gradient': 'linear-gradient(180deg, #525252 0%, #B8B8B8 100%)',
      },
      fontFamily: {
        dana: ['DanaFaNum', 'sans-serif'],
        danaFaNum: ['DanaFaNum', 'sans-serif'],
      },
    },
     keyframes: {
    spinProgress: {
      '0%': { transform: 'rotate(0deg)' },
      '100%': { transform: 'rotate(360deg)' },
    },
  },
  animation: {
    spinProgress: 'spinProgress 900s linear forwards', 
  },
  },
  plugins: [],
};


