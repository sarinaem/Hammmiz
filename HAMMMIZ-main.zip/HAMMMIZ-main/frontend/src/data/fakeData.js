const data = [
  {
    id: 1,
    name: 'انقلاب',
    latitude: 35.701065,
    longitude: 51.391214,
    address:
      'خیابان انقلاب، روبروی دانشگاه تهران، خیابان ۱۶ آذر پلاک ۸ رستوران همممیز',
    score: '4.6',
    open_at: '08:00:00',
    close_at: '23:00:00',
    metro_name: 'ولیعصر',
    distance_from_metro: '00:02:00',
    parking_name: 'حافظ',
    distance_from_parking: '00:03:00',
    landline_number: '02144435455',
    // image:
    //   "https://20d2-213-145-66-196.ngrok-free.app/media/hammmiz_images/Group_186.png",
  },

];

//   latitude: 51.34141343, longitude: 32.31531315,
export default data;
