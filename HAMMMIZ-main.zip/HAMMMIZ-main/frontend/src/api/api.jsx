import axios from 'axios';

// const baseURL = "http://hammmiz.com";

export const getLocations = async () => {
  try {
    const res = await axios.get(`http://hammmiz.com/main/hammmiz_locations/`);
    return res.data;

  } catch (err) {
    console.error('Error fetching locations:', err);
    return { results: [] };
  }
};

export const getTables = async () => {
  try {
    const response = await axios.get("/"); 
    console.log(response);
    
  } catch (err) {
    console.error('Error fetching tables:', err);
  }
};



// export const getDetailProduct = async({hammmiz_name, date, start_time, end_time}) => {
//   try {
//     const res = await axios.get(`${baseURL}/main/check_hammmiz/${hammmiz_name}/${date}/${start_time}/${end_time}`
// );
//     console.log(res.data);
//     return res.data;
//   } catch (err) {
//     console.log(err);
    
//   }
// };