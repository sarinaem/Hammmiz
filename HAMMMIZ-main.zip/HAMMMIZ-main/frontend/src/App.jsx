import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import React from 'react';

import './App.css';
import './index.css';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';


import MapView from './components/Map/Mapview';
import Onboarding from './components/Onboarding/Onboarding';
import Product from './components/Product/product';
import SelectTable from './components/Tabs/SelectTable';
import Home from './components/Home/Home';
import HamFood from './page/hamFood/hamFood';
import FoodMenu from "@/page/foodMenu/FoodMenu"
import ProductDetails from './page/ProductDetails/ProductDetails';
import Cart from './page/cart/Cart';
import Login from './page/Login/Login';
import OtpPage from './page/OtpPage/OtpPage';
import PaymentBill from './components/paymentBill/PaymentBill';
import PaymentDetail from './components/paymentBill/PaymentDetail.jsx';
import Profile from './page/Profile/Profile';
import Order from './components/Order/Order';
import UserData from './components/UserData/UserData';

const queryClient = new QueryClient();

function App() {
  return (
    <div className="font-dana max-w-[420px] mx-auto w-full container overflow-hidden box-border">
      <QueryClientProvider client={queryClient}>
        <Router>
          <Routes>
            <Route path="/" element={<Onboarding />} />
            <Route
              path="/map"
              element={
                <MapView
                  mapPoint={{ lat:35.69828445253599, lng: 51.39770695634084 }}
                />
              }
            />
            <Route path="/product" element={<Product />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/login" element={<Login />} />
            <Route path="/otp" element={<OtpPage />} />
            <Route path="/order" element={<Order />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/paymentBill" element={<PaymentBill />} />
            <Route path="/paymentDetail" element={<PaymentDetail />} />
            <Route path="/selectTable" element={<SelectTable />} />
            <Route path="/home" element={<Home />} />
            <Route path="/hamFood" element={<HamFood />} />
            <Route path="/foodMenu/:id" element={<FoodMenu />} />
            <Route path="/userData" element={<UserData />} />
            <Route path="/foodmenu/item/:id" element={<ProductDetails />} />
          </Routes>
        </Router>
      </QueryClientProvider>
    </div>
  );
}

export default App;
