import React, { useEffect, useState } from 'react';
import Navigations from "../../assets/Navigations.svg";
import admin from "@/assets/admin.svg";
import { CiShoppingCart } from 'react-icons/ci';
import Timer from '../Timer/Timer';


import { Link } from "react-router-dom";

import RotatingRings from "@/components/Category/RotatingRings"

const Home = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [clickUser, setClickUser] = useState(false);

  useEffect(() => {
    const data = localStorage.getItem("selectedLocation");
    if (data) {
      const loc = JSON.parse(data);
      setSearchTerm(loc.name);
    }
  }, []);

  return (
    <div className='flex flex-col items-center relative mt-[40.5px]'>

      {/* Top Input Box */}
      <div
        className="absolute font-normal w-[90%] leading-6 text-base top-[10px] flex flex-row-reverse gap-6 p-1 rounded-[40px] justify-between items-center bg-white"
        style={{
          zIndex: 1000,
          left: '50%',
          transform: 'translateX(-50%)',
          boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
        }}
      >
        <img src={admin} alt="admin" loading="lazy" />
        <div className="flex items-center flex-row gap-[6px] relative">
          <input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            type="text"
            className="text-[#525252] pr-2 leading-[23px] text-base font-danaFaNum font-normal text-right bg-transparent border-none outline-none"
            placeholder='همممیز انتخابی'
          />
          <div className="flex items-center w-5 h-5 cursor-pointer">
            <img loading="lazy"
              src={Navigations}
              className={`w-5 h-5 bg-none text-[#F87A08] absolute left-[39%] top-1 ${clickUser ? 'rotate-180' : ''}`}
              onClick={() => setClickUser(prev => !prev)}
            />
          </div>
        </div>
      </div>

      <div className='mt-[75px] flex justify-center gap-[270px] items-center w-full px-4 '>
        <div className="relative">
          <CiShoppingCart className="w-7 h-7 text-[#F87A08]" />
          <span className="absolute top-0 right-0 w-[11px] h-[13px] flex items-center justify-center text-white font-semibold text-[10px] leading-none bg-orange-500 rounded-full">
            ۱
          </span>
        </div>
        <Timer />
      </div>
        {/* category hammmiz */}
      <div>
        <RotatingRings />

      </div>
      <div className="mb-[67.16px] mt-[20px] flex flex-col items-center">
        <p className='font-danaFaNum text-[#000000] font-normal text-lg leading-[26px] text-center'>
          سفارشت رو هماهنگ کن.
        </p>
      </div>

      {/* Pay Button */}
      <Link to="/cart">
         <button
        className="text-white bg-[#27A74A] w-[345px] border-2 rounded-[50px] px-6 py-3 font-bold text-lg leading-[26px]"
         >
            پرداخت
          </button>
      
      </Link>

    </div>
  );
};

export default Home;
