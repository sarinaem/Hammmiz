import React from 'react';
import plan from "../../assets/tables.png";
import exampleTable from "../../assets/tableimage.svg";
const RestaurantCanvas = ({ setActiveTable, activeTable }) => {
  const tables = [
    { id: 14, number: 14, x: 209, y: 52.7, width: 66.19, height: 47, color: '#CE0A0A', borderRadius: 4, status: 'free' },
    { id: 11, number: 11, x: 267, y: 127.5, width: 57.17, height: 30, color: '#FFC107', borderRadius: 4, status: 'free' },
    { id: 1, number: 1, x: 65.3, y: 253.1, width: 84.24, height: 47, color: '#CE0A0A', borderRadius: 4, status: 'reserved' },
    { id: 9, number: 9, x: 267.9, y: 257.8, width: 84.24, height: 84, color: '#FFC107', borderRadius: 4, status: 'reserved' },
  ];
  

  return (
    <div className='relative bg-cover bg-no-repeat'>
      <img src={plan} loading="lazy" alt="table plan"
         className={`rounded-[34px] w-full transition-all duration-300 ${activeTable ? 'filter blur-sm' : ''}`} />

      {tables.map((table) => (
        <div
          key={table.id}
          onClick={() => setActiveTable(table)}
           className={`transition-all duration-300 relative
          ${activeTable && activeTable.id !== table.id ? 'filter blur-sm divide-opacity-100 scale-95' : 'z-50'}`}
          style={{
            position: 'absolute',
            top: `${(table.y - table.height / 2)}px`,
            left: `${(table.x - table.width / 2)}px`,
            width: activeTable && activeTable.id === table.id ? '145px' : `${table.width}px`,
            height: activeTable && activeTable.id === table.id ? '145px' : `${table.height}px`,
            borderRadius: `${table.borderRadius}px`,
            border: activeTable && activeTable.id === table.id ? 'none' : `3px solid ${table.color}`,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
      {activeTable && activeTable.id === table.id && (
          <div className=''>
             <div className="absolute inset-0 flex items-center justify-center z-[9999] rounded-lg " >
              <div className=" h-[165px] border-r-[2px] border-b-[2px] border-l-[2px] rounded-[16px] border-solid border-[#27A74A] 
               flex justify-center items-center flex-col bg-white w-[154px] overflow-hidden relative ">
                <img loading="lazy" src={exampleTable} alt="table enghelab" className='w-[145px] h-[145px] object-cover ' />
                <p className='text-[#525252] text-xs leading-8 font-normal font-danaFaNum text-center '>
                 تعداد صندلی: ۴
                </p>

              </div>
            </div>
          </div>
    
  )}
  

  <div
  className="fontbold font-dana text-xs leading-5 text-white shadow-[0px_4px_4px_0px_#00000040]
   flex justify-center items-center text-center z-[9999]"
  style={{
    backgroundColor: table.color,
    borderRadius: "100%",
    position: "absolute",
    ...(activeTable && activeTable.id === table.id
      ? { right: "0%", top: "100%", width: "22.53px", height: "22.53px", transform: "translate(50%, -50%)" } //blur
      : { left: "50%", top: "100%",  width: "15.04px",  height: "15px",  transform: "translate(-50%, -50%)" } 
    ),
  }}
>
  {table.number}
</div>

 

          
        </div>
      ))}
    </div>
  );
};

export default RestaurantCanvas;


