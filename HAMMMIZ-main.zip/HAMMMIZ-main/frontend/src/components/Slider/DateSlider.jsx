import React from 'react';



import Slider from 'rc-slider';
import 'rc-slider/assets/index.css';
import { toJalaali } from 'jalaali-js';



const months = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];

export const getJalaliDays = () => {
  const today = new Date();
  const days = [];

  const todayJalali = toJalaali(
    today.getFullYear(),
    today.getMonth() + 1,
    today.getDate()
  );
  const todayLabel = `${todayJalali.jd} ${months[todayJalali.jm - 1]}`;

  let todayIndex = 0;

  for (let i = 0; i < 31; i++) {
    const next = new Date();
    next.setDate(today.getDate() + i);
    const { jm, jd } = toJalaali(
      next.getFullYear(),
      next.getMonth() + 1,
      next.getDate()
    );
    const label = `${jd.toLocaleString('fa-IR')} ${months[jm - 1]}`;
    days.push(label);
    if (label === todayLabel) todayIndex = i;
  }

  return { days, todayIndex };
};

const DateLabels = ({ selectedIndex, days }) => {
  
  return (
    <div className="flex flex-col-reverse justify-center items-center h-[268px] mr-4 mb-4 text-xs font-dana font-bold leading-[18px]">
      {days.map((date, i) => {
        const distance = Math.abs(i - selectedIndex);
        const isVisible = distance <= 1 || i === 0 || i === days.length - 1;
        const isPrev = i === selectedIndex - 1;
        const isNext = i === selectedIndex + 1;
        return (
          <div
  //           style={{
  //   marginRight: (i === 0 || i === dates.length - 1) ? '8px' : '20px'
  // }}
            key={i}
            className={`h-[calc(268px/31)] flex items-center justify-between transition-all duration-300  
              ${
                i === selectedIndex
                  ? 'text-[#525252] mb-1 mt-1'
                  : isVisible
                    ? 'text-[#525252] opacity-40'
                    : 'opacity-0'
              }
              
             ${isPrev ? 'mb-1' : ''}
             ${isNext ? 'mt-1' : ''}
             

            `}

          >
            {date}
          </div>
        );
      })}
    </div>
  );
};

export default function DateSlider({ value, onChange }) {
  const { days } = getJalaliDays();
const isStart = value === 0;
const isEnd = value === days.length - 1;
  return (
    <div className="flex items-center justify-between">
      <div className="h-[268px] relative flex items-center justify-center ">
        <Slider
          vertical
          min={0}
          max={days.length - 1}
          value={value}
          onChange={onChange}
          step={1}
          trackStyle={[
            {
              backgroundColor: '#fff',
              border: '0.3px solid',
              boxShadow: '-4px 4px 3px #00000040 inset',
              width: 14,
              left: '50%',
              transform: 'translateX(-50%)',
            },
          ]}
          // main slider
          railStyle={{
            backgroundColor: '#fff',
            width: 11,
            height:268,
            left: '50%',
            transform: 'translateX(-50%)',
            border: '0.3px solid #000',
            boxShadow: '-4px 4px 3px #00000040 inset',
            borderRadius: '7',
          }}

          handleStyle={[{
            width: 40,
            height: 37.91,
            borderRadius: "50%",
            border: '4px solid transparent',
            padding: '2px',
            
            backgroundImage: `
                  radial-gradient(circle, #fff 70%, #FFFBF8 70%),
                  linear-gradient(white, white),
                  linear-gradient(180deg, #F87A08 0%, #F87A08 100%)

                `,
            backgroundOrigin: 'content-box, padding-box, border-box',
            backgroundClip: 'content-box, padding-box, border-box',
            backgroundRepeat: 'no-repeat',
            boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
            transform: 'none',
            marginBottom: isStart ? '0px' : isEnd ? '-28px' : '-4px',
            left: -9,

}]}
        
        />
      </div>
      <DateLabels selectedIndex={value} days={days} />
    </div>
  );
}
