import React, { useState } from 'react';

import RestaurantCanvas from '../Canvas/RestaurantCanvas';
import Situation from '../Situation/Situation';
import { Link } from 'react-router-dom';

import price from '../../assets/chairpriceicon.svg';

import exampleTable from "../../assets/tableimage.svg";
import CustomSwich from '../styles/CustomSwich';
import Counter from '../styles/Counter';


const SelectTable = () => {
  const [activeTable, setActiveTable] = useState(null);
  const [showPopup, setShowPopup] = useState(false);
  const [showCustomTable, setShowCustomTable] = useState(false);

  return (
    <div className="mx-6 sm:flex sm:justify-center sm:items-center sm:flex-col">
      <span className="font-bold text-base leading-8 text-right text-[#525252]">
        میز دلخواهت رو انتخاب و شخصی‌سازی کن:
      </span>
      <div className="flex mt-2 items-center text-right">
        <img  loading="lazy" src={price} alt="price for chair" />
        <p className="font-medium text-sm leading-6 text-[#525252]">
          هزینه اجاره هر صندلی: ۳۰ هزارتومان
        </p>
      </div>
      <div className='mt-3 mb-4'>
          <RestaurantCanvas activeTable={activeTable} setActiveTable={setActiveTable}  />
          <Situation />

      </div>
      <div className="flex items-center gap-3  justify-between mt-[49px]">
        <button
          className="
        bg-[#F87A08] font-bold text-lg leading-8 font-dana p-3 w-[166px] rounded-[40px] text-white"
         onClick={() => {
          if (activeTable) {
           setShowCustomTable(true);
          } else {
            setShowPopup(true);
          }
        }}
        >
          شخصی‌سازی
        </button>
     {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="p-6 bg-[#E6E6EA] rounded-[25px] flex gap-6 flex-col items-center justify-center">
            <p className="font-danaFaNum text-base leading-[23px] text-center font-normal text-[#525252] text-wrap w-[242px] opacity-[90%] ">برای شخصی‌سازی، نخست شماره میزت رو هماهنگ کن.</p>
            <button
              className="bg-[#F87A08] text-white outline-none border-0 w-[198px] rounded-[18.5px] font-danaFaNum font-normal text-[18px] leading-[26px]"
              onClick={() => setShowPopup(false)}
            >
                باشه
           </button>
          </div>
        </div>
)}
{showCustomTable && (

  <div className='fixed inset-0 bg-opacity-50 flex justify-center items-center z-50'>
    <div className='bg-[#E6E6EA] backdrop-blur-sm py-[34px] px-6 rounded-tl-[50px] rounded-tr-[50px]
    mt-[29px] mr-[26px] ml-6 w-[395px] '>
        <div className='flex gap-[21px]'>
          <div className='flex flex-col '>
              <span className='font-danaFaNum font-bold text-base mb-3'>
                میز شماره {activeTable.number.toLocaleString('fa-IR')}
              </span>
              <span className='text-sm leading-5 font-normal font-danaFaNum mb-8'>
                تعداد صندلی : ۴ 
              </span>
              <span className='w-[98px] text-right font-normal text-xs leading-6 '> 

                 چهارشنبه: ۱۴۰۳/۱۱/۰۳
                 <br />
                    زمان استفاده: ۱۲:۰۰ تا  ۱۴:۰۰
              </span>

          </div>
          <img loading="lazy" src={exampleTable} alt="table selected" />
        </div>
        <hr className='w-[328px] border-1 border-[#BFBFC0] mb-3 '/>
        <div>
            <p className='text-[#525252] font-danaFaNum font-bold leading-[23px] text-base'>
               شخصی‌سازی
            </p>
            <span className='text-[#525252] font-light leading-[18px] text-xs mt-3'>
              به ازای هر یک ابزار پذیرایی  ۵.۰۰۰ تومان و برای برگزاری تولد به ازای هر نفر ۱۰.۰۰۰ تومان به فاکتور شما اضافه می‌شود
            </span>
        </div>
      <div className='mt-3 grid grid-cols-2 gap-6 items-start'>
          <div className=''>
            <span className='relative flex gap-[9.26px] items-center mb-[10px]'>
              <span className='font-danaFaNum font-normal text-sm leading-5 text-[#525252] text-nowrap'>نیاز به صندلی بیشتر</span>
               <CustomSwich defaultChecked/>
            </span>
            <div className='mt-[10px] flex items-center gap-[12.5px]'>
              <span className='font-danaFaNum text-[#525252] text-sm leading-5 font-normal text-nowrap'>صندلی بزرگسال</span>
              <Counter />
              
            </div>
             <div className='mt-[10px] flex items-center gap-[22.47px] mb-[10px]'>
              <span className='font-danaFaNum text-[#525252] text-sm leading-5 font-normal text-nowrap'>صندلی کودک</span>
              <Counter />
              
            </div>
             <div className='relative flex gap-[9.26px] items-center'>
              <span className='font-danaFaNum font-normal text-sm leading-5 text-[#525252] text-nowrap'>برگزاری تولد</span>
              <div className='mr-[45.4px]'>
                <CustomSwich />
              </div>
            </div>
            
          </div>
          <div>
              <span className='relative flex gap-[45.26px] items-center'>
              <span className='font-danaFaNum font-normal text-sm leading-5 text-[#525252] text-nowrap'> ابزار پذیرایی</span>
               <CustomSwich defaultChecked/>
            </span>
            <div className='mt-[10px] flex items-center gap-[12.5px]'>
              <span className='font-danaFaNum text-[#525252] text-sm leading-5 font-normal text-nowrap'>لیوان شیشه‌ای</span>
              <Counter />
              
            </div>
             <div className='mt-[10px] flex items-center gap-[22.47px]'>
              <span className='font-danaFaNum text-[#525252] text-sm leading-5 font-normal text-nowrap'>قاشق چنگال</span>
              <Counter />
              
            </div>
             <div className='relative flex gap-[9.26px] items-center'>
              <span className='font-danaFaNum font-normal text-sm leading-5 text-[#525252] text-nowrap'>بشقاب پذیرایی</span>
                          <Counter />

            </div>
            
          </div>
        </div>
         <hr className='w-[328px] border-1 border-[#BFBFC0] my-3 '/>
         <span className='flex justify-center items-center'>
              <span className='my-3 leading-[23px] text-base font-bold text-[#525252] text-center'>قیمت نهایی: ۱۲۰.۰۰۰ تومان</span>

         </span>
       <Link to="/home">

      <button
        onClick={() => navigate('/selectTabel')}
        // w-[70%]
        className="text-white bg-[#F87A08] w-[345px] border-2 rounded-[50px] px-6 py-3 mb-[29px]"
      >
        برگزیدن
      </button>
      </Link>
    </div>
  </div>
)}



       <Link to="/home">
        <button
          className="border-2 border-[#F87A08] w-[166px] rounded-[40px] text-[#F87A08] p-3
          font-bold text-lg leading-8 font-dana"
        >
          رد کردن
        </button>
        </Link>
      </div> 
    </div>
  );
};

export default SelectTable;
