import React from 'react'


import admin from '../../assets/admin.svg';
import search from '../../assets/Search.svg';

const Search = () => {
  return (
         <div
                className="absolute font-normal leading-6 text-base top-[10px] flex flex-row-reverse gap-6 p-1 rounded-[40px] justify-between items-center bg-white"
                style={{
                  zIndex: 1000,
                  left: '50%',
                  transform: 'translateX(-50%)',
                  width: '90%',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                }}
              >
                <img src={admin} alt="admin" loading="lazy" />
                <div className="flex items-center flex-row-reverse gap-3">
                  <div>
                    <input
                      value={searchTerm}
                      type="text"
                      placeholder="همممیز خودت رو انتخاب کن"
                      className="text-[#525252] leading-[23px] text-base font-dana font-normal text-right bg-transparent border-none outline-none
                     placeholder:text-[#525252] w-full"
                    />
                  </div>
                  <div className="bg-[#F87A08] rounded-full object-contain flex justify-center items-center w-[40px] h-[40px] cursor-pointer">
                    <img src={search} alt="search" className="w-[18px] h-[18px]" loading="lazy" />
                  </div>
                </div>
              </div>
        
  )
}

export default Search