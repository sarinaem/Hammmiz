
  import React, { useState, useEffect } from 'react';

const Timer = () => {
  const totalSeconds = 15 * 60; // Total time in seconds (15 minutes)
  const [secondsLeft, setSecondsLeft] = useState(totalSeconds);

  useEffect(() => {
    const savedStartTime = localStorage.getItem('timerStartTime');
    let initialSeconds = totalSeconds;

    if (savedStartTime) {
      const elapsed = Math.floor((Date.now() - Number(savedStartTime)) / 1000);
      initialSeconds = Math.max(0, totalSeconds - elapsed);
    } else {
      localStorage.setItem('timerStartTime', Date.now().toString());
    }

    setSecondsLeft(initialSeconds);

    const interval = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds) => {
    const toFa = (num) => num.toString().padStart(2, "0").replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
    const minutes = toFa(Math.floor(seconds / 60));
    const remainingSeconds = toFa(seconds % 60);
    return `${minutes}:${remainingSeconds}`;
  };

  const radius = 18;
  const circumference = 2 * Math.PI * radius;
  const progress = (secondsLeft / totalSeconds) * circumference;

  return (
    <div className="relative w-[40px] h-[41px]">
      <svg
        className="rotate-[-90deg]"
        width="40"
        height="41"
        style={{
          background: "#E6E6EA",
          borderRadius: "100%",
          border: "#fff"
        }}
      >
        <circle
          cx="20"
          cy="20"
          r={radius}
          stroke="#F87A08"
          strokeWidth="2"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={progress}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-xs font-danaFaNum text-black">
        {formatTime(secondsLeft)}
      </div>
    </div>
  );
};

export default Timer;

