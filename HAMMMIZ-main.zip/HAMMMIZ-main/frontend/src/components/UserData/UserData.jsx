import React, { useState } from 'react'
import { IoIosArrowForward } from 'react-icons/io'
import { Link } from 'react-router-dom'
import pen from "@/assets/Pen.svg"
const UserData = () => {
    const [edit, setEdit] = useState(false);
    const [name, setName] = useState(" هلیا شعبانی ");
    const [email, setEmail] = useState("heliashams80@gmail.com  ")
    const [tempName, setTempName] = useState(name);
    const [tempEmail, setTempEmail] = useState(email);

   const handleSave = () => {
    setName(tempName);
    setEmail(tempEmail);
    setEdit(false);
    console.log({ name: tempName, email: tempEmail });
  };

    const handleEdit = () => {
    setEdit(true);
    setTempName(name);
    setTempEmail(email);
  };

  return (
    <div>
        <div className='flex justify-start items-center mt-[90px] mx-6 gap-[16.5px]'>
           <Link to="/home">
             <IoIosArrowForward className="text-[#F87A08] w-6 h-6 font-bold" />
            </Link>
            <span>داده‌های کاربر</span>
        </div>
        <div className='flex items-center justify-center mx-6'>
            <hr className='w-[323px] border-[#999999] border opacity-50'/>
            <img src={pen} alt="edit text" className='mb-4' onClick={handleEdit}
 />
        </div>
        <div className='flex flex-col gap-[2px] mb-[57px]'>
            <span className='flex gap-[4px] mt-3 mr-6'>
                <span className='font-danaFaNum font-normal leading-[20px] text-sm text-black'>
                نام و نام خانوادگی:
            </span>
            {edit ? (
            <input
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
              className='border border-gray-300 px-2 py-1 rounded text-sm text-[#525252]'
            />
          ) : (
            <span className='font-danaFaNum font-normal leading-5 text-sm text-[#525252]'>{name}</span>
          )}
            </span>
               <span className='flex gap-[4px] mt-2 mr-6'>
                <span className='font-danaFaNum font-normal leadiong-[20px] text-sm text-black'>
                شماره موبایل:
            </span>
            <span className='font-danaFaNum font-normal leading-5 text-sm text-[#525252]'>۰۹۱۲۸۳۸۴۹۸۶</span>
            </span>
               <span className='flex gap-[4px] mt-2 mr-6'>
                <span className='font-danaFaNum font-normal leadiong-[20px] text-sm text-black'>
                ایمیل:   
            </span>
                  {edit ? (
            <input
              value={tempEmail}
              onChange={(e) => setTempEmail(e.target.value)}
              className='border border-gray-300 px-2 py-1 rounded text-sm text-[#525252]'
            />
          ) : (
            <span className='font-danaFaNum font-normal leading-5 text-sm text-[#525252]'>{email} </span>
          )}
            </span>
        </div>
        <div className="mx-6">
            <button  onClick={handleSave}
            className=' flex justify-center items-center font-danaFaNum 
            text-center bg-[#F87A08] text-white font-bold text-lg leading-8 rounded-[40px] mb-8 mt-[400px] w-full py-3'>
                به‌روزرسانی
            </button>
        </div>
    </div>
  )
}

export default UserData