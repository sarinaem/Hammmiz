import React from 'react'


import { IoIosArrowForward } from 'react-icons/io'


import logoTable from "@/assets/logoSite.svg"
const Order = () => {
  return (
    <div>
        <div className='flex flex-row justify-between mt-[84px] mb-6'>
            <IoIosArrowForward className="text-[#09090B] w-6 h-6 font-bold relative -translate-y-1" />
            <span className='text-center mx-auto'>سفارش‌ها</span>
        </div>
        <hr className=' border-[#999999] border-[0.25px] w-[393px] opacity-[25%]'/>
        <div>
          <span className='flex justify-center mt-6'> 
            <span>کد پیگیری سفارش: </span>
            <span className='mr-[2px]'> ۱۲۳۴۵۶۷۸۹۱۰۱۱۱۲۱ </span>
          </span>
          
         <div className='flex flex-col border-[#999999] rounded-[25px] border bg-[#FFFFFF] w-[345px] p-4 mx-4 mt-4'>
             <div className='flex gap-[17px] items-center'>
                 <img src={logoTable} alt="logo for table" className='w-[40px] h-[40px]'  loading="lazy"/>
                 <h3 className=''>همممیز انقلاب </h3>
             </div>

            <div className='w-[313px] flex gap-8'>
                <span className='font-light text-sm leading-[20px] font-danaFaNum text-[#525252] mt-[4.5px]'>چهارشنبه: ۱۴۰۳/۱۱/۰۳ از 
                    <br />
                    ساعت: ۱۲:۰۰ تا ۱۴:۰۰</span>
                <span className='text-[#525252] font-light text-base leaing-[23px] flex flex-col'>
                    <span>
                        شماره‌میز: ۱۰
                    </span>
                    <span>تعداد صندلی : ۴</span>
                </span>
           </div>
         </div>
        </div>
       
    </div>
  )
}

export default Order