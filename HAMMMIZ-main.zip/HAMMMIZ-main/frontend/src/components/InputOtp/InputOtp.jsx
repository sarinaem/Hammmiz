import React from 'react'

const InputOtp = () => {
  return (
    <div>
        <label htmlFor="phone" className='sr-only'>شماره موبایل</label>
            <input 
             dir='rtl'
              type="tel" 
              name='phone' 
              id='phone' 
              pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" 
              className='border border-solid border-[#F87A08] outline-none rounded-full w-[50px] h-[50px] px-4 text-center'
            />
    </div>
  )
}

export default InputOtp