import React, { useState } from 'react';
import { Box, Button, Typography } from '@mui/material';
import { Add, Remove } from '@mui/icons-material';

const Counter = () => {
  const [count, setCount] = useState(0);

  return (
    <Box display="flex" alignItems="center" gap={"1px"} flexDirection={'row-reverse'}>
      <Button
        variant="outlined"
        onClick={() => setCount(prev => Math.max(0, prev - 1))}
        sx={{
          borderRadius: "50%",
          width: 20,
          height: 20,
          border: "1px solid #F87A08",
          minWidth: 0,
          padding: 0,
        }}
      >
        <Remove  htmlColor="#F87A08" sx={{ fontSize: 16 }}/>
      </Button>

      <Typography variant="h6"   sx={{
          color: '#F87A08',
          fontFamily: "danaFaNum",
          fontWeight: '500',
          fontSize: 24,
          minWidth: 32,
          textAlign: 'center',
        }}>{count.toLocaleString("fa-IR")}</Typography>

      <Button
        variant="outlined"
        onClick={() => setCount(prev => prev + 1)}
        sx={{
          borderRadius: "50%",
          width: 20,
          height: 20,
          
          border: "1px solid #F87A08",
          minWidth: 0,
          padding: 0,
        }}
      >
        <Add  htmlColor="#F87A08" sx={{ fontSize: 16 }} />
      </Button>
    </Box>
  );
};

export default Counter;
