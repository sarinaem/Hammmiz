import { styled } from "@mui/material/styles";
import { Switch } from '@mui/material';

const CustomSwich = styled(Switch)(({}) => ({
  // small circle
'& .MuiSwitch-thumb': {
  width: 20,
  height: 20.58,
   borderRadius: "50%",
   border: '3px solid transparent',
    padding: '2px',
    backgroundImage: `

      radial-gradient(circle, 159.66deg, #B0A6A5 -6.86%, #FFFBF8 111.54%),
      linear-gradient(white, white),
      linear-gradient(180deg, #F87A08 0%, #F87A08 100%)
    `,
      backgroundOrigin: 'content-box, padding-box, border-box',
      backgroundClip: 'content-box, padding-box, border-box',
      backgroundRepeat: 'no-repeat',
      boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
      transform: 'none',
      position: 'relative',

},

'& .MuiSwitch-switchBase.Mui-checked .MuiSwitch-thumb': { 
    backgroundImage: `
    radial-gradient(circle, #ffffff 60%, #ffe0cc 100%),
    linear-gradient(white, white),
    linear-gradient(180deg, #F87A08 0%, #F87A08 100%)
  `,
  // boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
 },

'& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
  background: "#F87A08",
  opacity: "100%",
  borderRadius: 20,
  boxShadow: '0px -4px 4px 0px #00000040 inset',

  height: 12, 
  width: 32.92
  

},


'& .MuiSwitch-track': {
  background: "#C2CFD6",
  boxShadow: '0px -4px 4px 0px #00000040 inset',

}
}))

export default CustomSwich;
