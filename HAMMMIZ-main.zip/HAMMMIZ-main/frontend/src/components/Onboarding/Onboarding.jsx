import logo from '@/assets/logoSite.svg';
import nameSite from '@/assets/hammmiz-2.svg';
import { Link } from 'react-router-dom';
import React from 'react';

const Onboarding = () => {
  return (
    <div className="bg-[#f87A08] flex flex-col justify-between items-center h-screen min-h-[100dvh] px-4">
      <div className="flex flex-col items-center gap-[52px] mt-[30px]">
        <img src={logo} alt="logo website" className="w-[200px] h-[200px]"  loading="lazy"/>
        <img src={nameSite} alt="name of site"  loading="lazy" />
        <span className="font-normal font-danaFaNum leading-[26px] text-lg text-[#FFF7F7] text-center mt-[2px] mb-[20px]">
          با همممیز، میز و غذاهای دلخواهت رو هماهنگ کن
        </span>
      </div>

      <Link
        to="/map"
        className="text-[#f87A08] text-center font-bold text-lg w-[90%] bg-white px-6 py-2 rounded-[50px] leading-8 mb-8"
      >
        آغاز
      </Link>
    </div>
  );
};

export default Onboarding;
