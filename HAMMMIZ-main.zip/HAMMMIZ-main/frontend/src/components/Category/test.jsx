import React from 'react';
import './rotating.css';

import Hamcoffee from "@/assets/Ham coffee.svg"
import Hambread from "@/assets/Ham bread.svg"
import HamFood from "@/assets/Ham food.svg"
import HamRestaurant from "@/assets/Ham restaurant.svg"
import HamPazHome from "@/assets/Ham  pez home.svg"
import logoHammmiz from "@/assets/logoSite.svg"

const RotatingRings = () => {
  return (
  <div className="relative w-[352px] h-[352px] mx-auto mt-[75.33px] ">

    <div className='absolute inset-0 animate-spin-slow rounded-full border border-solid border-[#00000040] w-[352px] h-[352px]'>
            <div className='absolute top-0 left-1/4 transform -translate-x-1/2 -translate-y-1/2'>
              <img loading="lazy" src={Hamcoffee} alt="Hamcoffee" />
            </div>
            <div className='absolute top-0 right-1/4 transform translate-x-1/2 -translate-y-1/2'>
              <img loading="lazy" src={HamFood} alt="HamFood" />
            </div>
          </div>


    <div className="absolute inset-6 animate-spin-slower rounded-full border border-solid border-[#00000040]">
        <div className="absolute flex justify-between items-center right-0 top-3/4 transform -translate-y-1/2 w-full">
            <div className='flex justify-center items-center'>
                <img loading="lazy" src={HamPazHome} alt="HamPazHome" className="" />
            </div>
            <div className='flex justify-center items-center'>
                <img loading="lazy" src={Hambread} alt="Hambread" className="" />
            </div>
        </div>
    </div>

<div className="absolute inset-14 rounded-full border border-solid border-[#00000040]">
  <div className="absolute inset-0 animate-spin flex items-start justify-center">
      <img loading="lazy" src={HamRestaurant} alt="HamRestaurant" />
  </div>
</div>


    {/* لوگوی مرکزی */}
    <div className="absolute inset-0 flex items-center justify-center">
        <img loading="lazy" src={logoHammmiz} alt="logo" className="w-[120px] h-[120px] " />
    </div>
</div>

  );
};

export default RotatingRings;
