import React from 'react';
import './rotating.css';

import Hamcoffee from "@/assets/Ham coffee.svg";
import Hambread from "@/assets/Ham bread.svg";
import HamFood from "@/assets/Ham food.svg";
import HamRestaurant from "@/assets/Ham restaurant.svg";
import HamPazHome from "@/assets/Ham  pez home.svg";
import logoHammmiz from "@/assets/logoSite.svg";
import { useNavigate } from 'react-router-dom';


const RotatingRings = () => {
  const navigate = useNavigate();

  return (
    <div className="relative w-[352px] h-[352px] mx-auto mt-[75px] mb-[83px] aspect-square bg-white rounded-lg select-none">

      {/* دایره بزرگ */}
      <div className="absolute inset-[-11px] rounded-full border border-gray-300">
        <div
          role="button"
          tabIndex={0}
          onClick={() => alert('Hamcoffee clicked')}
          className="absolute top-[10%] left-[15%] transform -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-lg p-2 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          aria-label="Ham Coffee Section"
        >
          <img 
            loading="lazy"
            width="61.94px"
            height="55.74px"
            src={Hamcoffee} 
            alt="Ham Coffee" 
            className="pointer-events-none select-none"
          />
        </div>

        <button
          onClick={() => navigate("/hamFood")}
          aria-label="Go to Ham Food"
          className="absolute top-[85%] right-[10%] transform translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          type="button"
        >
          <img 
            loading="lazy"
            width="52.25px"
            height="71.74px"
            src={HamFood} 
            alt="Ham Food" 
            className="pointer-events-none select-none"
          />
        </button>
      </div>

      {/* دایره وسط */}
      <div className="absolute inset-[25px] rounded-full border border-gray-300">
        <div
          role="button"
          tabIndex={0}
          onClick={() => alert('Ham Paz Home clicked')}
          className="absolute top-1/2 left-0 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-lg p-2 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          aria-label="Ham Paz Home Section"
        >
          <img 
            loading="lazy"
            src={HamPazHome}
            width="51.87px"
            height="84.74px"

            alt="Ham Paz Home" 
            className="pointer-events-none select-none"
          />
        </div>

        <div
          role="button"
          tabIndex={0}
          onClick={() => alert('Ham Bread clicked')}
          className="absolute top-[25%] right-[10px] transform translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-lg p-2 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          aria-label="Ham Bread Section"
        >
          <img 
            width="55.74px"
            height="55.74px"
            loading="lazy"
            src={Hambread} 
            alt="Ham Bread" 
            className="pointer-events-none select-none"
          />
        </div>
      </div>

      {/* دایره کوچک */}
      <div className="absolute inset-[70px] rounded-full border border-gray-300">
        <div
          role="button"
          tabIndex={0}
          onClick={() => alert('Ham Restaurant clicked')}
          className="absolute bottom-[-10px] left-1/2 transform -translate-x-1/2 translate-y-1/2 cursor-pointer rounded-lg p-2 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
          aria-label="Ham Restaurant Section"
        >
          <img
            loading="lazy"
            width="56.17px"
            height="55.74px"
            src={HamRestaurant}
            alt="Ham Restaurant"
            className="pointer-events-none select-none"
          />
        </div>
      </div>

      <div className="absolute inset-0 flex items-center justify-center select-none pointer-events-none">
        <img
          loading="lazy"
          src={logoHammmiz}
          alt="Site Logo"
          className="w-[120px] h-[120px]"
        />
      </div>
    </div>
  );
};

export default RotatingRings;

