import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapContainer, Marker, TileLayer, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

import { getLocations } from '@/api/api';
import LocateButton from '../LocationUser/LocationUser';

import admin from '../../assets/admin.svg';
import search from '../../assets/Search.svg';
import Location from '../../assets/Location.svg';

const StaticMap = () => {
  const [locations, setLocations] = useState([]);
  const [activeLocation, setActiveLocation] = useState(null);
  const [activeId, setActiveId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [hideProfile, setHideProfile] = useState(false);

  const navigate = useNavigate();
  const inputRef = useRef();

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const results = await getLocations();
        console.log(results);
        
        setLocations(results);

      } catch (err) {
        setLocations([]);
      }
    };

    fetchLocations();
  }, []);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setShowResults(true);
  };

  const handleSelectLocation = (loc) => {
    setActiveLocation(loc);
    setActiveId(loc.id);
    setSearchTerm(loc.name);
    setShowResults(false);
    inputRef.current?.blur();
    localStorage.setItem('selectedLocation', JSON.stringify({ name: loc.name }));
  };

  const toggleActive = (id) => {
    const loc = locations.find((l) => l.id === id);
    setActiveId((prev) => (prev === id ? null : id));
    setActiveLocation(loc);
  };

  const getIcon = (id, name) => {
    if (!name) return null;

    const isActive = activeId === id;
    const iconImage = isActive ? '/active.svg' : '/disable.svg';

    return L.divIcon({
      className: '',
      html: `
        <div style="display: flex; flex-direction: column; align-items: center;">
          <img src="${iconImage}" alt="icon image" style="width: 40px; height: 40px;" />
          <span style="font-size: 14px; font-weight: 700; color: #525252; direction: rtl;">
            ${name}
          </span>
        </div>
      `,
      iconSize: [40, 50],
      iconAnchor: [20, 40],
    });
  };

  const ZoomToLocation = ({ location }) => {
    const map = useMap();

    useEffect(() => {
      if (location) {
        map.setView([location.latitude, location.longitude], 20, {
          animate: true,
          duration: 1.5,
        });
      }
    }, [location, map]);

    return null;
  };
const filteredLocations = locations.filter(
  (loc) =>
    loc.name.toLowerCase().includes(searchTerm.toLowerCase())
);

  return (
    <div className="relative w-full h-screen min-h-[100dvh] mx-auto">
      {/* Search Box */}
      <div className="absolute top-[10px] mt-[10%] left-1/2 transform -translate-x-1/2 z-[1000] w-[90%] text-base leading-6" style={{ boxShadow: '0px 4px 12px rgba(0,0,0,0.06), 0px -4px 12px rgba(0,0,0,0.06)' }}
>
        <div className="bg-white  rounded-t-[22px] flex flex-row-reverse gap-4 py-2 px-4 items-center">
          {hideProfile ? <div style={{ width: '40px', height: '40px' }} /> : <img src={admin} alt="admin" />}
          <div className="flex items-center flex-row-reverse gap-3 w-full">
            <input
              ref={inputRef}
              value={searchTerm}
              onChange={handleSearch}
              onFocus={() => setHideProfile(true)}
              onBlur={() => setHideProfile(false)}
              placeholder="همممیز خودت رو انتخاب کن"
              className="text-[#525252] placeholder:text-[#525252] font-danaFaNum bg-transparent border-none outline-none w-full"
            />
            <div className="bg-[#F87A08] rounded-full w-[40px] h-[40px] flex justify-center items-center cursor-pointer">
              <img src={search} alt="search" className="w-[18px] h-[18px] rounded-full" loading="lazy" />
            </div>
          </div>
        </div>

        {showResults && (
            <ul className='bg-white rounded-b-[22px] max-h-[200px] overflow-y-auto flex flex-col gap-[25px]'>
            {filteredLocations.length && 
            
            filteredLocations.map((loc) => (
                <li
                  key={loc.id}
                  onClick={() => handleSelectLocation(loc)}
                  className="cursor-pointer px-4 py-2 hover:bg-gray-100 bg-white flex items-center gap-[4.5px] text-right mt-5 rounded-[22px]"
                >
                  <img src={Location} alt="loc" className="w-6 h-6" loading="lazy" />
                  <span className="text-base text-[#525252] font-danaFaNum">همممیز {loc.name}</span>
                </li>
              ))
          
             
            }
          </ul>
        )}
      </div>

      {/* Map */}
      <MapContainer
        center={activeLocation ? [activeLocation.latitude, activeLocation.longitude] : [ 35.69828445253599, 51.39770695634084 ]}
        zoom={12}
        scrollWheelZoom
        attributionControl={false}
        zoomControl={false}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {locations.length > 0 &&
          locations.map((loc) => {
            const icon = getIcon(loc.id, loc.name);
            if (!icon) return null;

            return (
              <Marker
                key={loc.id}
                position={[loc.latitude, loc.longitude]}
                icon={icon}
                eventHandlers={{
                  click: (e) => {
                    toggleActive(loc.id);
                    e.target.closePopup();
                  },
                }}
              >
                <Popup>
                  {loc.name}</Popup>
              </Marker>
            );
          })}

        {activeLocation && <ZoomToLocation location={activeLocation} />}
        <LocateButton />
      </MapContainer>

      {/* Select Button */}
      <div className="absolute top-[90%] left-1/2 transform -translate-x-1/2 z-[1000] w-[90%] sm:w-[80%] flex flex-col items-center">
        <button
          onClick={() => navigate('/product')}
          disabled={!activeId}
          className={`py-2 w-[95%] mx-6 rounded-[50px] text-white text-lg font-bold font-danaFaNum leading-[26px] ${
            activeId ? 'bg-orange-500' : 'bg-[#999999]'
          }`}
        >
          برگزیدن
        </button>
      </div>
    </div>
  );
};

export default StaticMap;
