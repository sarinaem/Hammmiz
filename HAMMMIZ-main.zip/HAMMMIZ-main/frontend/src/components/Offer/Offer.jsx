import React from 'react'
import Counter from '../styles/Counter'




const Offer = ({img, title, price}) => {
  return (
    <div className='bg-[#FFFFFF80] rounded-[40px] w-[300px] mx-6 flex flex-row items-center justify-center gap-[10px]'>
        <img src={img} alt='img' loading="lazy" className=' h-auto
' />
        <div className='flex flex-col'>
            <h2 className='font-danaFaNum text-base font-normal leading-[23px] mt-[7.5px] '>{title}</h2>
            <div className='flex gap-2 items-center'>
                <span className=' text-[#707070] font-danaFaNum font-normal leading-[20px] text-sm '>
                    {price}
                </span>
                <Counter />
            </div>
        </div>
            
    </div>
  )
}

export default Offer