import React from 'react'


import paymentBill from "@/assets/paymentBill.svg"
import { Link } from 'react-router-dom'


const PaymentBill = () => {
  return (
  <div className=''>
      <div className='flex flex-col mb-[84.25px] ml-[15px] mr-[17px]'>
        <img src={paymentBill} alt="payment-bill" />
        <p className='text-[#27A74A] font-bold text-base leading-[23px] font-danaFaNum text-center'>سپاس‌گزاریم! همممیز و غذاتون هماهنگ شد.</p>
      </div>
        <div className='border border-solid border-[#DEDEDE] shadow-[2px 2px 6px 0px #0000000A] rounded-[12px] p-4 flex gap-[9px] flex-col' style={{ backgroundColor: "var(--Grays-White, #FFFFFF)" }}>
            <h3 className='mt-4 font-danaFaNum font-medium text-base leading-[23px] text-[#2A2A2A]'>اطلاعات تراکنش</h3>
            <div className='flex flex-col gap-2'>
                <span className='flex flex-roew justify-between'>
                    <span className='font-danaFaNum font-normal text-sm leading-5 text-[#6B7280]'>
                        زمان
                    </span>
                    <span className='text-[#585252] font-medium leading-5 text-sm'> شنبه, ۲۹ دی ۱۴۰۳</span>
                </span>
              <span className='flex flex-roew justify-between'>
                    <span className='font-danaFaNum font-normal text-sm leading-5 text-[#6B7280]'>
                        مبلغ
                    </span>
                    <span className='text-[#585252] font-medium leading-5 text-sm'> ۳۷۸.۰۰۰ تومان </span>
                </span>
                <span className='flex flex-roew justify-between'>
                    <span className='font-danaFaNum font-normal text-sm leading-5 text-[#6B7280]'>
                        سپرده مبدا
                    </span>
                    <span className='text-[#585252] font-medium leading-5 text-sm'>۶۲۱۹۸۶۱۹۴۵۸۶۱۲۳۸</span>
                </span>
                <span className='flex flex-roew justify-between'>
                    <span className='font-danaFaNum font-normal text-sm leading-5 text-[#6B7280]'>
                        شماره پیگیری
                    </span>
                    <span className='text-[#585252] font-medium leading-5 text-sm'>۲۹۴۴۱۵۱</span>
                </span>
                <span className='flex flex-roew justify-between'>
                    <span className='font-danaFaNum font-normal text-sm leading-5 text-[#6B7280]'>
                        شماره مرجع
                    </span>
                    <span className='text-[#585252] font-medium leading-5 text-sm'> ۴۳۳۸۱۸۲۹۴۴۵۱</span>
                </span>
            </div>
        </div>
        <div className='mt-[96px] flex gap-[12px] flex-col justify-center items-center'>
          {/* <Link to="/paymentDetail"> */}
             <button className="text-white bg-[#F87A08] w-[345px] border-1 border-[#F87A08] rounded-[50px] px-6 py-3 font-bold text-lg leading-[26px]">
             جزئیات پرداخت
          </button>
          <Link to="/home">
           <button
               className="text-[#F87A08] mb-8 bg-white w-[345px] border ease-out duration-300 border-[#F87A08] rounded-[50px] px-6 py-3 font-bold text-lg leading-[26px]"
         >
            بازگشت به خانه
          </button>
          </Link>
        </div>
  </div>
  )
}

export default PaymentBill