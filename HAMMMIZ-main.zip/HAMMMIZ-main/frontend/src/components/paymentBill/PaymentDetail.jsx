import React from 'react'


import paymentlogo from "@/assets/paymentlogo.svg"
import { Link } from 'react-router-dom'

const PaymentDetail = () => {
  return (
    <div className=' ml-[23px] mr-[25px]'>
        <div className='flex flex-col gap-10 items-center'>
            <img src={paymentlogo} alt="payment-logo" className='w-[90px] h-[90px] mt-[50px]' loading="lazy" />
            <p className='font-bold leading-[23px] text-base font-danaFaNum text-[#2A2A2A]'>جزئیات پرداخت شما: </p>
        </div>
        <div className='mt-[63px] text-[#525252] font-medium text-base leadding-[23px] font-danaFaNum'>
            <span className='flex justify-center'> 
                <span>کد پیگیری سفارش: </span>
                <span className='mr-[2px]'> ۱۲۳۴۵۶۷۸۹۱۰۱۱۱۲۱
                </span>
            </span>
            <div className='flex flex-col'>
             <span className='flex justify-between gap-[110.49px] mt-4'>
               <span>میز ۴ نفره شماره ۱۰</span>
              <span>۱۲۰.۰۰۰ تومان</span>
             </span>
             <hr className='border-[1px] opacity-50  border-solid mx-auto border-[#999999] w-full my-4'/>
              <span className='flex justify-between  gap-[46.98px] text-nowrap mt-4'>
               <span>پیتزا پپرونی ۲۳ سانتی متری</span>
              <span>۲۵۸,۰۰۰ تومان</span>
             </span>
               <hr className='border-[1px] opacity-50 border-solid mx-auto border-[#999999] w-full my-4'/>

             </div>

        </div>
        <div className='mt-[180.9px] mb-[56px] flex justify-between'>
            <span className='font-danaFaNum text-lg leading-[26px] font-bold'>جمع کل پرداختی:</span>
            <span className='font-danaFaNum text-lg leading-[26px] font-bold'>۳۷۸.۰۰۰ تومان</span>
        </div>
       <div className='mb-5 text-center flex justify-center items-center'>
      <Link to="/home">
      <button
        className="text-[#F87A08] mb-8 bg-white w-[345px] border ease-out duration-300 border-[#F87A08] rounded-[50px] px-6 py-3 font-bold text-lg leading-8"
    >
        بازگشت به خانه
    </button>
    </Link>
</div>

    </div>
  )
}

export default PaymentDetail