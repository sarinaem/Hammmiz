import InputOtp from '@/components/InputOtp/InputOtp'
import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom';

const OtpPage = () => {
    const [minute, setMinute] = useState(2);
    const [second, setSecond] = useState(0);
    const location = useLocation();
    const navigate = useNavigate();
      const phone = location.state?.phone || "";

    useEffect(() => {
        const interval = setInterval(() => {
            if (second > 0) {
                setSecond(second - 1);
            }
            if (second === 0) {
                if (minute === 0) {
                    clearInterval(interval);
                } else {
                    setSecond(59);
                    setMinute(minute - 1);
                }
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [second, minute]);

     const resetTimer = () => {
        setMinute(2);
        setSecond(0);
    };

 useEffect(() => {
   if (!phone) {
    navigate("/login");
    return null;
  }
 }, [phone])

 
    return (
        <div className='flex flex-col justify-center items-center mt-[152px] px-4'>
            <h1 className='text-[#525252] leading-[35px] font-bold text-2xl'>ورود</h1>
            <div className='flex flex-col gap-4 justify-center items-center w-full'>
                <h3 className='text-[#525252] font-medium text-base leading-[23px] text-center mt-[56px]'>
                    کد تایید رو وارد کن:
                </h3>
                <div className='flex flex-row gap-3 mt-6'>
                    <InputOtp />
                    <InputOtp />
                    <InputOtp />
                    <InputOtp />
                    <InputOtp />
                </div>
                <div className='flex justify-around flex-row gap-[180px] items-center text-[#525252] font-normal text-xs leading-lg font-danaFaNum'>
                    <span className=''>ویرایش</span>
                    <span>{phone}</span>
                </div>
                <span className='flex gap-2 text-[#525252] font-light text-base leading-[23px] mt-4'>
                    زمان باقی‌مانده:
                    {minute > 0 || second > 0 ? (
                        <span>
                            {minute.toLocaleString("fa-IR")}:
                            {second.toLocaleString("fa-IR").padStart(2, '۰')}
                        </span>
                    ) : (
                        <span onClick={resetTimer}>ارسال مجدد کد</span>
                    )}
                </span>
                <button className='mt-6 font-danaFaNum text-center bg-[#F87A08] text-white font-bold text-lg leading-8 rounded-[50px] w-full py-3 '>
                    ورود
                </button>
            </div>
        </div>
    )
}

export default OtpPage
