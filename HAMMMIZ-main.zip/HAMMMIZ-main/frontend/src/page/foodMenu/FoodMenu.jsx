import React, { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom';

import resturantheader from "@/assets/resturantheader.svg"
import { IoIosArrowForward } from 'react-icons/io'
import { CiShoppingCart } from 'react-icons/ci'
import Timer from '@/components/Timer/Timer'
import shilaFood from "@/assets/food/shilaFood.svg"
import { FaStar } from 'react-icons/fa6'
import pizza from "@/assets/pizza.svg"

import Postmotor from "@/assets/Postmotor.svg"
import Clock from "@/assets/Clock.svg"
import Counter from '@/components/styles/Counter'


const FoodMenu = () => {
  const navigate = useNavigate();
  const {id} = useParams()
  const [activeMenu, setActiveMenu] = useState("offer")
  const datas = [
    { id: 1, name: "offer", lable: "پیشنهادها" },
    { id: 2, name: "pizza", lable: "پیتزا" },
    { id: 3, name: "burger ", lable: "برگر" },
    { id: 4, name: "appetiser", lable: "پیش‌غذا" }
  ];


    const Items = [
    {
      id: 1, name:"پیتزا پپرونی 23 سانتی متری", price: "258,000 تومان"
    },  {
        id: 2, name:"پیتزا پپرونی 23 سانتی متری", price: "258,000 تومان"

    },
      {
        id: 3, name:"پیتزا پپرونی 23 سانتی متری", price: "258,000 تومان"

    }
  ]

  return (
    <div className="relative w-full">
      <img  loading="lazy" src={resturantheader} alt="restaurant header" className="w-full h-auto" />

      {/* Header Buttons */}
      <div className="absolute top-1 left-0 right-0 px-6 flex justify-between items-center z-10 w-full">
        <Link to="/home">
          <div className="bg-[#FFFFFFCC] rounded-full w-10 h-10 flex items-center justify-center">
            <IoIosArrowForward className="text-[#F87A08] w-6 h-6" />
          </div>
        </Link>

        <div className="flex flex-col items-center gap-3 mt-[25%]">
          <div className="relative w-10 h-10 bg-[#FFFFFFCC] rounded-full flex items-center justify-center">
            <CiShoppingCart className="w-6 h-6 text-[#F87A08]" />
            <span className="absolute -top-[2px] -right-[2px] w-[13px] h-[13px] bg-orange-500 text-white text-[10px] font-semibold flex items-center justify-center rounded-full">
              ۱
            </span>
          </div>

          <div className="mb-1">
            <Timer />
          </div>
        </div>
      </div>

      {/* Shila Icon */}
      <div className="flex items-center justify-between px-4 -mt-10 z-10 relative">
        <div className="flex items-center gap-3">
          <img  loading="lazy" src={shilaFood} alt="shila food" className="" />
        
        </div>
        </div>

      {/* Restaurant Info */}
      <div className="px-4 mt-4 flex flex-col gap-2">
        <div className="flex justify-between items-center">
          <span className="font-danaFaNum font-bold text-lg text-[#525252]">شیلا (مطهری)</span>
          <span className="flex items-center gap-1 font-danaFaNum font-bold text-base text-[#525252]">
            ۴.۲
            <FaStar className="text-[#F87A08] w-4 h-4" />
          </span>
        </div>

        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <img  loading="lazy" src={Postmotor} alt="delivery" />
            <span className="font-danaFaNum text-sm text-[#525252]">
              زمان تحویل: ۳۰ تا ۶۰ دقیقه
            </span>
          </div>

          <div className="flex items-center gap-2">
            <img  loading="lazy" src={Clock} alt="working hours" />
            <span className="font-danaFaNum text-sm text-[#525252]">
              ۷ صبح تا ۱۲:۰۰ شب
            </span>
          </div>
        </div>
        {/* Menu product */}
      <div className="bg-[#E6E6EA] rounded-[40px] p-[4px] flex gap-[22px] mt-8">
        {datas.map((data) => {
          const isActive = activeMenu === data.name;
          return (
              <button
              key={data.id}
                className={`px-4 py-2 rounded-[20px] w-[50%] font-bold text-[14px] leading-6 text-nowrap ${
                  isActive ? 'text-white bg-[#F87A08]' : 'text-gray-600'
                }`}
                onClick={() => setActiveMenu(data.name)}
              >
                {data.lable}
              </button>
          );
        })}  
      </div>
       {activeMenu === "offer" && (
              <div className='mt-6 flex flex-col gap-[25px] w-[295px] mb-[23px]'>
            {
              Items.map(item => {
                return (
                  <div className='bg-[#FDFDFD] flex gap-[18px] border border-[#000000] border-solid rounded-[100px]' key={item.id}
                   style={{ boxShadow: "0px 4px 4px 0px #00000040" 
                   }}
                  onClick={() => navigate(`/foodmenu/item/${item.id}`)}
                  //  onClick = {() => handleClick(item)}
      >
                      <div className='flex flex-row gap-[18px]'>
                        <img  loading="lazy" src={pizza} alt="pizza" className='w-[70px] h-[70px] m-[10px] ml-[-6px]' style={{
                          // border: "1px solid rgba(0, 0, 0, 0.478)",
                          // boxShadow: "0px 4px 4px 0px #00000040"
                        }} />
                        <div className='flex flex-col justify-center ml-[-4px] gap-[4px]'>
                          <h3 className='font-danaFaNum text-base leading-[23px] text-[#525252] font-bold'>{item.name}</h3>
                          <div className='flex justify-between items-center gap-5'>
                            <span className='font-danaFaNum font-normal text-sm leading-[20px] text-[#525252]'>
                                  {item.price?.toLocaleString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d])}
                              
                              </span>
                             <Counter />
                                
                          </div>
                         
                        </div>
                      </div>
                    </div>
                )
      
              })
            }
      
              </div>
            )}
      </div>


    </div>
  )
}

export default FoodMenu
