import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate()
    const [phone, setPhone] = useState("");
 
    const toPersianDigits = (str) => {
  return str.replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
};
    const handleChange = (e) => {
    const value = e.target.value;
          setPhone(toPersianDigits(value))

    }
    
    const handleDirekt = () => {
      navigate("/otp", {state : {phone}});

    }

  return (
    <div className='flex flex-col justify-center items-center mt-[152px] px-4'>
        <h1 className='text-[#525252] leading-[35px] font-bold text-2xl'>ورود</h1>
        <div className=' flex flex-col gap-4 justify-center items-center w-full max-w-md'>
            <h3 className='text-[#525252] font-medium text-base leading-[23px] text-center mt-[56px]'>
                شماره موبایلت رو وارد کن:
            </h3>
            <label htmlFor="phone" className='sr-only'>شماره موبایل</label>
            <input 
             dir='rtl'
            value={phone} 
              onChange={handleChange}
              type="tel" 
              name='phone' 
              id='phone' 
              pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" 
              className='border border-solid border-[#E6E6EA] hover:border-[#F87A08] focus:border-[#F87A08] outline-none rounded-[50px] w-full h-[50px] px-4 text-center'
              placeholder="۰۹۱۰۲۳۴۵۶۷۸"
            />
         
             <button className='font-danaFaNum text-center bg-[#F87A08] text-white font-bold text-lg leading-8 rounded-[50px] w-full py-3' onClick={handleDirekt}>
                ورود
            </button>
        </div>
    </div>
  )
}

export default Login
