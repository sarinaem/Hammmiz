import React, { useState } from 'react'
import { CiShoppingCart } from 'react-icons/ci';
import { IoIosArrowForward } from 'react-icons/io';
import HamFood from "@/assets/Ham food.svg"

import { Link, useNavigate } from 'react-router-dom';
import Timer from '@/components/Timer/Timer';
import { FaStar } from "react-icons/fa6";
import shilaFood from "@/assets/food/shilaFood.svg"

const HammmFoodList = () => {
  const [activeMenu, setActiveMenu] = useState("all");
  const navigate = useNavigate();
  const handleClick = (item) => {
    navigate(`/foodMenu/${item.id}`)
  }

  const datas = [
    { id: 1, name: "all", lable: "همه" },
    { id: 2, name: "pizza", lable: "پیتزا" },
    { id: 3, name: "berger", lable: "برگر" },
    { id: 4, name: "sokhari", lable: "سوخاری" }
  ];


  const Items = [
    {
      id: 1, name:"پیتزا شیلا", score: "4.2", deliveryStart: "۳۰", deliveryEnd: "۶۰"
    }, {
      id: 2, name:"پیتزا شیلا", score: "4.2", delivery: "تحویل ۲۰ تا ۶۰ دقیقه"
    }, {
        id: 3, name:"پیتزا شیلا", score: "4.2", delivery: "تحویل ۳۰ تا ۵۰ دقیقه"

    }
  ]
  

  return (
    <div className='mt-[90px] mx-6'>
      <div className='flex justify-between'>
        <Link to="/home">
          <IoIosArrowForward className="text-[#F87A08] w-6 h-6 font-bold" />
        </Link>
        <img loading="lazy" src={HamFood} alt="" />

        <div className='flex gap-3 flex-col items-center'>
          <div className="relative">
            <CiShoppingCart className="w-7 h-7 text-[#F87A08]" />
            <span className="absolute top-0 right-0 w-[11px] h-[13px] flex items-center justify-center text-white font-semibold text-[10px] leading-none bg-orange-500 rounded-full">
              ۱
            </span>
          </div>
          <Timer />
        </div>
      </div>

      <div className="bg-[#E6E6EA] rounded-[40px] p-[4px] flex gap-[22px] mt-8">
        {datas.map((data) => {
          const isActive = activeMenu === data.name;
          return (
              <button
              key={data.id}
                className={`px-4 py-2 rounded-[20px] w-[50%] font-bold text-[14px] leading-6 text-nowrap ${
                  isActive ? 'text-white bg-[#F87A08]' : 'text-gray-600'
                }`}
                onClick={() => setActiveMenu(data.name)}
              >
                {data.lable}
              </button>
          );
        })}
      </div>

      {activeMenu === "all" && (
        <div className='mt-6 flex flex-col gap-[25px] w-[295px]'>
      {
        Items.map(item => {
          return (
            <div className='bg-[#FDFDFD] flex gap-[18px] border border-[#000000] border-solid rounded-[100px]' key={item.id}
             style={{ boxShadow: "0px 4px 4px 0px #00000040" 
             }} onClick = {() => handleClick(item)}
>
                <div className='flex flex-row gap-[18px]'>
                  <img loading="lazy" src={shilaFood} alt="" className='m-[10px] ml-0' />
                  <div className='flex flex-col justify-center ml-[-4px] gap-[4px]'>
                    <h3 className='font-danaFaNum text-lg leading-[26px] text-black font-normal'>{item.name}</h3>
                    <span className='flex items-center gap-[2px]'>
                      <FaStar className='text-[#F87A08] border-[1.5px] w-3 h-[11.33px] border-none' />
                      <span>{item.score.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d])}</span>
                    </span>
                    <span className='font-danaFaNum font-normal text-sm leading-[20px] text-[#8F8F8F] mb-[14px]'>
                      تحویل   {item.deliveryStart} تا   {item.deliveryEnd}
                    
                    </span>
                  </div>
                </div>
              </div>
          )

        })
      }

        </div>
      )}
    </div>
  );
};

export default HammmFoodList;
