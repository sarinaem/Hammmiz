import React from 'react'

import { IoIosArrowForward } from 'react-icons/io'
import { Link } from 'react-router-dom';

import foodImg from "@/assets/foodimage.svg"
import Delster from "@/assets/Delster.svg"
import Garlicbread from "@/assets/Garlic-bread.svg"
import salad from "@/assets/salad.svg"

 

import Timer from '@/components/Timer/Timer';
import { FaStar } from 'react-icons/fa6';
import Counter from '@/components/styles/Counter';
import Offer from '@/components/Offer/Offer';



const ProductDetails = () => {


    const comments = [
        {
            id:1, name: "پارسا", score: "۵", date: "۱۷ خرداد ۱۴۰۴", opinion:"عالی بود مثل همیشه "
        },
        {
            id:2, name: "عسل", score: "۴", date: "۱۷ خرداد ۱۴۰۴", opinion:"معمولی بود "
        },
    ]
  return (
    <div className='mt-[90px]'>
      <div className='flex items-center px-6 sm:px-0'>
        <Link to="/foodMenu/:id">
          <div className="bg-[#FFFFFFCC] rounded-full w-10 h-10 flex items-center justify-center">
            <IoIosArrowForward className="text-[#F87A08] w-6 h-6" />
          </div>
        </Link>
        <h1 className='font-danaFaNum font-normal text-lg leading-[26px] text-black mr-4'>شیلا (مطهری)</h1>
      </div>
      <div className='flex justify-center items-center relative mt-6 px-6 sm:px-0'>
        <img loading="lazy" src={foodImg} alt="foodImg" className="max-w-full h-auto" />
        <div className="absolute top-3 left-5">
          <Timer />
        </div>
      </div>
      <div 
        className="bg-[#E6E6EA] w-full max-w-[395px] mx-auto
          absolute top-[281px] sm:top-[281px] rounded-tl-[25px] rounded-tr-[25px] z-[9999] shadow-[0_4px_4px_0_rgba(0,0,0,0.25)]"
      >
        <div className='flex justify-between items-center gap-4 sm:gap-[80px] px-6 pt-[23px]'>
          <p className='font-bold font-danaFaNum text-lg leading-[26px] text-[#525252] whitespace-nowrap'>
            پیتزا پپرونی ۲۳ سانتی متری
          </p>
          <span className="flex items-center justify-end gap-1 font-bold font-danaFaNum text-lg leading-[26px] text-[#525252]">
            ۴.۹
            <FaStar className="text-[#F87A08] w-5 h-5" />
          </span>
        </div>
        <p className='font-normal leading-5 text-sm font-danaFaNum text-[#525252] mt-[11px] px-6 pb-6'>
          خمیر پیتزا کلاسیک، کالباس پپرونی، قارچ، فلفل هالوپینو، پنیر موزارلا
        </p>
        <div className='flex justify-between items-center mx-6'>
            <span className='font-danaFaNum font-bold leading-[26px] text-lg text-[#525252]'>۲۵۸,۰۰۰ تومان</span>
            <Counter />
        </div>
         <hr  className='border border-solid border-[#BFBFC0] my-4 mx-[25px] '/>
         <div className='flex gap-4 flex-col'>
            <h3 className='font-danaFaNum font-medium leading-[23px] text-base text-[#525252] mx-6'>همممزه های پیشنهادی:</h3>
            <div className='flex flex-col gap-2'>
                <Offer loading="lazy" img={Garlicbread} title="نان سیر" price="۱۵۰,۰۰۰ تومان"/>
                <Offer loading="lazy" img={salad} title="سالاد کاهو" price="۶۰,۰۰۰ تومان"/>
                <Offer loading="lazy" img={Delster} title="دلستر" price="۲۵,۰۰۰ تومان"/>

            </div>
            <div className='mt-8 mb-[22px]'>
                 <h2 className='text-black font-bold leading-[23px] font-danaFaNum text-base text-center'>
                        نظر کاربران:
                    </h2>
                {comments.map((comment) => {
                    return <div className='flex flex-col mx-[25px]' key={comment.id}>
                            <span className='flex flex-row justify-between mt-3'>
                                <span className='font-medium text-base leading-[23px] font-danaFaNum '>{comment.name}</span>
                                 <span className='flex gap-[4px]'>
                                     {comment.score}
                                     <FaStar className="text-[#F87A08] w-5 h-5" />    
                                 </span>
                            </span>
                             <span className='font-light font-danaFaNum text-xs leading-[18px] text-[#525252]'>{comment.date}</span>
                                <span className='font-danaFaNum font-normal leading-[23px] text-base text-[#525252]'>{comment.opinion}</span>
                          
                        </div>
                })}
                      
            </div>
         </div>
         <Link to="/cart">
            <button className='my-8 mx-6 bg-[#F87A08] px-6 py-3 rounded-[50px] w-[345px] h-[50px] text-white font-bold text-lg leading-8 '>
                سبد خرید (۲)
             </button>
         </Link>
      
      </div>
     
    </div>
  )
}

export default ProductDetails

