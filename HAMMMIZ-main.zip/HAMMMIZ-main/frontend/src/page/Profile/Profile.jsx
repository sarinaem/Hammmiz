import { Link } from "react-router-dom";
import UserImg from "@/assets/UserImg.svg"
import plus from "@/assets/Plus.svg"
import support from "@/assets/support.svg"
import MyProfile from "@/assets/Profile.svg"
import logOut from "@/assets/logOut.svg"
import history from "@/assets/history.svg"
import arrowRight from "@/assets/Arrow-Right.svg"
import suggest from "@/assets/suggest.svg"
import { useRef, useState } from "react";

const Profile = () => {
  const datas = [
    { id: 1, name: "داده‌های کاربری", img: MyProfile, link: "/userData" },
    { id: 2, name: "تاریخچه سفارش‌ها", img: history },
    { id: 3, name: "پشتیبانی", img: support },
    { id: 4, name: "معرفی به دوستان", img: suggest },
    { id: 5, name: "خروج ", img: logOut }
  ];

  
  const [profileImage, setProfileImage] = useState(UserImg);
  const inputFileRef = useRef(null);

  const handleClickUpload = () => {
    inputFileRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setProfileImage(imageUrl);

    }
  };

  return (
    <div className='mt-[90px] mx-6'>
      <p className='text-right text-[#525252] font-bold text-base leading-[23px] font-danaFaNum mb-8 mr-8'>حساب کاربری</p>
      <div className='flex gap-2 items-center'>
        <div className='relative inline-block' onClick={handleClickUpload}>
          <img loading="lazy" src={profileImage} alt="user profile" className='border-[1.44px] border-[#FFFFFF] rounded-full object-cover w-[60px] h-[60px]' />
          <img loading="lazy" src={plus} alt="plus and add img" className='absolute top-10 right-8' />
           <input
            type="file"
            accept="image/*"
            ref={inputFileRef}
            onChange={handleFileChange}
            style={{ display: "none" }}
          />
        </div>
        <div className='flex flex-col'>
          <h1 className='font-danaFaNum font-bold text-2xl leading-[35px] text-[#525252] '>هلیا شعبانی</h1>
          <span className='font-light text-sm leading-[20px] text-[#525252]'>۰۹۱۲۸۳۸۴۹۸۶</span>
        </div>
      </div>

      <div className='mt-[42px]'>
        {datas.map((data) => {
          const content = (
            <div className='flex justify-between mt-[18px]'>
              <div className='flex justify-start gap-3'>
                <img loading="lazy" src={data.img} alt="profile" className=' w-6 h-6' />
                <span className='font-normal  leading-[18px] text-lg font-danaFaNum text-black'>{data.name}</span>
              </div>
              <img loading="lazy" src={arrowRight} alt="arrow right" />
            </div>
          );

          return (
            <div key={data.id} className='flex flex-col ml-[34px] mr-[20px]'>
              {data.link ? <Link to={data.link}>{content}</Link> : content}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Profile;
