import React from 'react';
import { IoIosArrowForward } from 'react-icons/io';
import homeIcon from '@/assets/HomeHammiz.svg';
import logoTable from '@/assets/logoSite.svg';
import cartShopping from '@/assets/cartShopping.svg';
import { Link } from 'react-router-dom';

const Cart = () => {
  const cartItems = []; 

  return (
    <div>
      <div className='flex flex-row justify-between mt-[84px] mb-6 ml-[23px] mr-6'>
        <Link to="/product">
          <IoIosArrowForward className="text-[#525252] w-6 h-6 font-bold relative -translate-y-1" />
        </Link>
        <span className='text-center mx-auto leading-[26px] font-normal text-lg text-[#525252] font-danaFaNum'>سبد خرید شما</span>
        <Link to="/home">
           <img loading="lazy" src={homeIcon} alt="home icon" />
        </Link>
      </div>

      <hr className='border-[#999999] border-[0.25px] w-full opacity-[25%]' />

      <div className='flex flex-col items-center justify-center mt-6'>

        {cartItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center mt-[142px]">
            <img loading="lazy" src={cartShopping} alt="خالی بودن سبد" className="w-[150px] h-[150px]" />
            <p className="text-[#525252] mt-4 text-base font-danaFaNum">سبد خرید شما خالی است</p>
          </div>
        ) : (
          cartItems.map((item, index) => (
            <div key={index} className='flex flex-col border-[#999999] rounded-[25px] border bg-[#FFFFFF] w-[345px] p-4 mx-4 mt-4'>
              <div className='flex gap-[17px] items-center'>
                <img loading="lazy" src={logoTable} alt="" className='w-[40px] h-[40px]' />
                <h3>{item.branch}</h3>
              </div>

              <div className='w-[313px] flex gap-8'>
                <span className='font-light text-sm leading-[20px] font-danaFaNum text-[#525252] mt-[4.5px] ml-2 mb-[12.5px]'>
                  {item.date} <br />
                  ساعت: {item.time}
                </span>
                <span className='text-[#525252] font-light text-base leading-[23px] flex flex-col'>
                  <span>شماره‌میز: {item.tableNumber}</span>
                  <span>تعداد صندلی : {item.seats}</span>
                </span>
              </div>

              <span>
                قیمت:
                <span className='text-[#525252] font-medium text-base leading-[23px] font-danaFaNum'>
                  {item.price} تومان
                </span>
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Cart;
