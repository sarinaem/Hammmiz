// public/service-worker.js

self.addEventListener('install', (event) => {
  console.log('✅ Service Worker Installed');
  event.waitUntil(
    caches.open('v1').then((cache) => {
      return cache.addAll([
        '/',
        '/index.html',
        '/logo.svg',
      ]);
    })
  );
});

self.addEventListener('activate', (event) => {
  console.log('✅ Service Worker Activated');
});

self.addEventListener('fetch', (event) => {
  console.log('⏩ Fetching:', event.request.url);
});
