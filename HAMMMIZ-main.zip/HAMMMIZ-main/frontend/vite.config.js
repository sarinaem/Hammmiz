import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tsconfigPaths from 'vite-tsconfig-paths';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    tsconfigPaths(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'HAMMMIZ',
        short_name: 'HAMMMIZ',
        description: 'My Progressive Web App',
        theme_color: '#F87A08',
        background_color: '#F87A08',
        display: 'standalone',
        start_url: '/',
        icons: [
          {
            src: '/Icon/hammmizIcon.png',
            sizes: '192x192',
            type: 'image/png',
          },
          {
            src: '/Icon/hammmizIcon512.png',
            sizes: '512x512',
            type: 'image/png',
          },
        ],
      },
    }),
  ],
});
