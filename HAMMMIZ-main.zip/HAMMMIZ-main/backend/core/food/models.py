from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal
from main.models import HammmizModel


class FoodCategoryModel(models.Model):
    hammmiz = models.ManyToManyField(HammmizModel)
    name = models.CharField(max_length=50)
    icon = models.ImageField(upload_to="food_category_icons/")

    def __str__(self):
        return f"{self.name}"


class FoodTypeModel(models.Model):
    food_category = models.ForeignKey(FoodCategoryModel, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.name}"


class FoodModel(models.Model):
    food_type_supported = models.ForeignKey(FoodTypeModel, on_delete=models.CASCADE)
    restaurant = models.ForeignKey("accounts.RestaurantProfile", on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    image = models.ImageField(upload_to="food_images/")
    price = models.DecimalField(
        max_digits=8,
        decimal_places=0,
        validators=[
            MinValueValidator(Decimal("0")),
        ],
    )
    discount_percent = models.PositiveIntegerField(
        default=0, validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    score = models.DecimalField(
        max_digits=2,
        decimal_places=1,
        validators=[
            MinValueValidator(Decimal("0.0")),
            MaxValueValidator(Decimal("5.0")),
        ],
        default=Decimal("0.0"),
    )
    recipe = models.CharField(max_length=100)

    def offer(self):
        if self.discount_percent:
            return self.price - (self.price * self.discount_percent) / 100
        return self.price

    def __str__(self):
        return f"{self.name}"
