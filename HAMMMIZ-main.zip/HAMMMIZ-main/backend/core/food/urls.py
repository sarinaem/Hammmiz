from django.urls import path
from . import views

app_name = "Products"

urlpatterns = [
    path(
        "category/<str:hammmiz>/",
        views.FoodCategoryView.as_view(),
        name="food-category",
    ),
    path(
        "restaurant/<str:food_category>/",
        views.RestaurantView.as_view(),
        name="restaurant",
    ),
    path("type/<str:food_category>/", views.FoodTypeView.as_view(), name="food-type"),
    path("list/<str:restaurant>/", views.FoodListView.as_view(), name="food-list"),
    path("get/<int:pk>/", views.FoodGetView.as_view(), name="food-get"),
]
