from rest_framework import serializers
from .models import FoodCategoryModel, FoodTypeModel, FoodModel
from accounts.models import RestaurantProfile


class FoodTypeSerializer(serializers.ModelSerializer):
    food_category = serializers.StringRelatedField()

    class Meta:
        model = FoodTypeModel
        fields = "__all__"
        read_only_fields = ["id"]


class RestaurantSerializer(serializers.ModelSerializer):
    food_type = FoodTypeSerializer(many=True)

    class Meta:
        model = RestaurantProfile
        fields = "__all__"
        read_only_fields = ["id"]


class FoodCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = FoodCategoryModel
        fields = ["id", "name", "icon"]
        read_only_fields = ["id"]


class FoodSerializer(serializers.ModelSerializer):
    food_type_supported = FoodTypeSerializer()
    offer = serializers.SerializerMethodField()
    # absolute_url = serializers.SerializerMethodField(method_name="get_abs_url")
    
    class Meta:
        model = FoodModel
        fields = ['food_type_supported', 'id', 'name', 'image', 'price', 'discount_percent', 'score', 'recipe', 'offer']
        read_only_fields = ['id', 'created_at', 'updated_at', 'restaurant', 'offer']

    def get_offer(self, obj):
        return obj.offer()

    def create(self, validated_data):
        user = self.context['request'].user
        validated_data['restaurant'] = user.restaurant_profile
        return super().create(validated_data)
    
    # def get_abs_url(self, obj):
    #     request = self.context.get("request")
    #     return request.build_absolute_uri(obj.pk)