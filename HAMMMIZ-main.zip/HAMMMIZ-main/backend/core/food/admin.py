from django.contrib import admin
from .models import FoodCategoryModel, FoodTypeModel, FoodModel

admin.site.register(FoodCategoryModel)
admin.site.register(FoodTypeModel)
admin.site.register(FoodModel)
