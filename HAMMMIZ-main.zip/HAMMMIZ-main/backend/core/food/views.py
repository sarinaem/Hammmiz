from rest_framework import generics
from django_filters.rest_framework import DjangoFilterBackend
from .models import FoodCategoryModel, FoodTypeModel, FoodModel
from accounts.models import RestaurantProfile
from .serializers import (
    FoodCategorySerializer,
    RestaurantSerializer,
    FoodTypeSerializer,
    FoodSerializer,
)


class FoodCategoryView(generics.ListAPIView):
    serializer_class = FoodCategorySerializer

    def get_queryset(self):
        hammmiz_name = self.kwargs.get("hammmiz")
        queryset = FoodCategoryModel.objects.all()
        if hammmiz_name:
            queryset = queryset.filter(hammmiz__name=hammmiz_name).distinct()
        return queryset


class RestaurantView(generics.ListAPIView):
    serializer_class = RestaurantSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["food_type__name"]

    def get_queryset(self):
        food_category = self.kwargs.get("food_category")
        queryset = RestaurantProfile.objects.all()
        if food_category:
            queryset = queryset.filter(
                food_type__food_category__name=food_category
            ).distinct()
        return queryset


class FoodTypeView(generics.ListAPIView):
    serializer_class = FoodTypeSerializer

    def get_queryset(self):
        food_category = self.kwargs.get("food_category")
        queryset = FoodTypeModel.objects.all()
        if food_category:
            queryset = queryset.filter(food_category__name=food_category).distinct()
        return queryset


class FoodListView(generics.ListAPIView):
    queryset = FoodModel.objects.all()
    serializer_class = FoodSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["food_type_supported"]

    def get_queryset(self):
        restaurant = self.kwargs.get("restaurant")
        queryset = FoodModel.objects.all()
        if restaurant:
            queryset = queryset.filter(restaurant__restaurant_name=restaurant).distinct()
        return queryset

class FoodGetView(generics.RetrieveAPIView):
    queryset = FoodModel.objects.all()
    serializer_class = FoodSerializer
    lookup_field = "pk"

    def get_object(self):
        pk = self.kwargs.get("pk")
        return generics.get_object_or_404(FoodModel, pk=pk)