from .base import *
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

DEBUG = False

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ),
}

# Security headers
SECURE_BROWSER_XSS_FILTER = True  # Helps prevent some XSS attacks
SECURE_CONTENT_TYPE_NOSNIFF = True  # Stops the browser from MIME-sniffing
X_FRAME_OPTIONS = 'DENY'  # Prevents clickjacking

# HTTPS

# SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
# SECURE_SSL_REDIRECT = True
# SESSION_COOKIE_SECURE = True
# CSRF_COOKIE_SECURE = True

sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN"),
    integrations=[DjangoIntegration()],
    send_default_pii=True,
)