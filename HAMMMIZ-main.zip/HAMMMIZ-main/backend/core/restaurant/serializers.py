from rest_framework import serializers
from food.models import FoodModel
from payment.models import PaymentItemModel
from payment.serializers import PaymentSerializer

class RestaurantOrderSerializer(serializers.ModelSerializer):
    payment = PaymentSerializer()
    food = serializers.StringRelatedField()
    hammmiz = serializers.SerializerMethodField()
    price = serializers.SerializerMethodField()
    class Meta:
        model = PaymentItemModel
        fields = ['hammmiz', 'payment', 'food', 'quantity', 'price', 'created_date']

    def get_hammmiz(self, obj):
        return obj.payment.hammmiz.table.hammmiz.name
    
    def get_price(self, obj):
        return obj.total_price()