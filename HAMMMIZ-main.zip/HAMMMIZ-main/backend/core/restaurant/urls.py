from django.urls import path
from rest_framework.routers import DefaultRouter
from . import views

app_name = "restaurant"

urlpatterns = [
    path("order/", views.RestaurantOrderView.as_view(), name="restaurant_order"),
]

router = DefaultRouter()
router.register("food", views.RestaurantFoodViewSet, basename="food")
urlpatterns += router.urls