from rest_framework.permissions import BasePermission
from django.core.exceptions import ObjectDoesNotExist

class IsRestaurantUser(BasePermission):
    """
    Allows access only to users with user_type 'restaurant'.
    """

    def has_permission(self, request, view):
        user = request.user
        if not (user and user.is_authenticated and getattr(user, "user_type", None) == "restaurant"):
            return False
        try:
            restaurant_profile = user.restaurant_profile
        except ObjectDoesNotExist:
            return False
        if not restaurant_profile:
            return False
        return getattr(restaurant_profile, "hammmiz_validation", False)