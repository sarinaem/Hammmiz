from rest_framework import generics, viewsets
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter
from .permissions import IsRestaurantUser
from .serializers import RestaurantOrderSerializer
from food.serializers import FoodSerializer
from food.models import FoodModel
from payment.models import PaymentItemModel
    
class RestaurantOrderView(generics.ListAPIView):
    permission_classes = [IsRestaurantUser]
    serializer_class = RestaurantOrderSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter]
    search_fields = ["payment__user__user_profile__first_name", "payment__user__user_profile__last_name"]
    
    def get_queryset(self):
        user = self.request.user
        qs = PaymentItemModel.objects.filter(food__restaurant=user.restaurant_profile, 
                                             payment__status='successful')
        return qs
    

class RestaurantFoodViewSet(viewsets.ModelViewSet):
    permission_classes = [IsRestaurantUser]
    serializer_class = FoodSerializer
    queryset = FoodModel.objects.all()
    filter_backends = [DjangoFilterBackend, SearchFilter]
    search_fields = ["name"]
    
    def get_queryset(self):
        user = self.request.user
        qs = FoodModel.objects.filter(restaurant=user.restaurant_profile)
        return qs