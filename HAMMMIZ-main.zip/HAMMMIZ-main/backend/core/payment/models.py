from django.db import models
from django.contrib.auth import get_user_model
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
import jdatetime
import secrets

User = get_user_model()


class CartModel(models.Model):
    hammmiz = models.ForeignKey(
        "main.ReservationModel",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="carts",
    )
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE)
    guest_token = models.UUIDField(null=True, blank=True, db_index=True)
    created_date = models.DateTimeField(auto_now_add=True)

    total_price = models.DecimalField(
        max_digits=10,
        decimal_places=0,
        default=0,
    )

    def __str__(self):
        return f"{self.user} - {self.guest_token}"

    def save(self, *args, **kwargs):
        if self.user and self.guest_token:
            raise ValueError("Cart cannot have both user and guest_token.")
        super().save(*args, **kwargs)



class CartItemModel(models.Model):
    cart = models.ForeignKey(CartModel, on_delete=models.CASCADE, related_name="items")
    food = models.ForeignKey("food.FoodModel", on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.cart} - {self.food} - {self.quantity}"

# PaymentModel
class PaymentModel(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    authority = models.CharField(max_length=40)
    hammmiz = models.ForeignKey(
        "main.ReservationModel",
        on_delete=models.CASCADE,
        related_name="payments",
    )
    amount = models.DecimalField(decimal_places=0, max_digits=10)
    status = models.CharField(
        max_length=20,
        choices=[
            ("successful", "Successful"),
            ("failed", "Failed"),
        ],
        default="failed",
    )
    ref_id = models.CharField(max_length=100)
    follow_up_code = models.CharField(max_length=16, blank=True, editable=False)
    card_number = models.CharField(max_length=16)
    
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user} - {self.amount} - {self.status}"
    
    def calculate_total(self):
        total = sum(item.price * item.quantity for item in self.items.all()) + self.hammmiz.final_price
        return total
        
    
class PaymentItemModel(models.Model):
    payment = models.ForeignKey(PaymentModel, on_delete=models.CASCADE, related_name="items")
    food = models.ForeignKey("food.FoodModel", on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=0)

    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def total_price(self):
        return self.price * self.quantity

    def __str__(self):
        return f"{self.payment.user} - {self.food.name} - {self.quantity} - {self.price}"
    


@receiver(post_save, sender=PaymentModel)
def generate_follow_up_code(sender, instance, created, **kwargs):
    if created and not instance.follow_up_code:
        jalali_datetime = jdatetime.datetime.fromgregorian(datetime=instance.created_date)
        jalali_str = f"{jalali_datetime.year:04d}{jalali_datetime.month:02d}{jalali_datetime.day:02d}"
        
        random_part = ''.join(secrets.choice('0123456789') for _ in range(8))
        follow_up_code = f"{jalali_str}{random_part}"

        # Safe update without triggering signals again
        PaymentModel.objects.filter(pk=instance.pk).update(follow_up_code=follow_up_code)