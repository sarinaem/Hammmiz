import requests
import json
from django.conf import settings


class ZarinPalSandbox:

    verifivation_url = (
        "https://sandbox.zarinpal.com/pg/v4/payment/verify.json"
    )

    def __init__(self, merchant_id=settings.MERCHANT_ID):
        self.merchant_id = merchant_id

    def payment_verification(self, amount, authority):
        payload = {
            "merchant_id": self.merchant_id,
            "amount": amount,
            "authority": authority,
        }
        headers = {"Content-Type": "application/json"}

        response = requests.post(
            self.verifivation_url, headers=headers, data=json.dumps(payload)
        )
        return response.json()