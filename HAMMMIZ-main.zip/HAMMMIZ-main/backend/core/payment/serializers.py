# serializers.py
from rest_framework import serializers
from .models import CartModel, CartItemModel, PaymentModel
from main.serializers import ReservationSerializer
from food.serializers import FoodSerializer

class CartItemSerializer(serializers.ModelSerializer):
    food = FoodSerializer()

    class Meta:
        model = CartItemModel
        fields = ["food", "quantity"]

class CartSerializer(serializers.ModelSerializer):
    hammmiz = ReservationSerializer()
    items = CartItemSerializer(many=True)
    total_price = serializers.SerializerMethodField()

    class Meta:
        model = CartModel
        fields = ["hammmiz", "items", "total_price"]
        
    def get_total_price(self, obj):
        total = 0
        for item in obj.items.all():
            price = item.food.offer()  # This applies discount if present
            total += price * item.quantity
        if obj.hammmiz and obj.hammmiz.final_price:
            total += obj.hammmiz.final_price
        return total
    

class CartItemAddSerializer(serializers.Serializer):
    food_id = serializers.IntegerField()
    quantity = serializers.IntegerField(min_value=1)


class CartItemRemoveSerializer(serializers.Serializer):
    food_id = serializers.IntegerField()
    
class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentModel
        fields = ['follow_up_code', 'user', 'amount', 'hammmiz', 'created_date']
        read_only_fields = ['follow_up_code']