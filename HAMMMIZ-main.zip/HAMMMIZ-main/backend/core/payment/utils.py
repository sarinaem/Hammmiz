from .models import CartItemModel, CartModel
from django.contrib.auth.models import AnonymousUser


def get_or_create_cart(request):
    user = request.user
    guest_token = request.headers.get("X-Guest-Token")  # Frontend must send this

    if user and not isinstance(user, AnonymousUser):
        cart, _ = CartModel.objects.get_or_create(user=user)
    elif guest_token:
        cart, _ = CartModel.objects.get_or_create(guest_token=guest_token)
    else:
        cart = None  # Frontend must provide guest_token for anonymous users

    return cart


def merge_guest_cart_to_user(guest_token, user):
    guest_cart = CartModel.objects.filter(guest_token=guest_token).first()
    if guest_cart:
        user_cart, _ = CartModel.objects.get_or_create(user=user)
        for item in guest_cart.items.all():
            user_item, created = CartItemModel.objects.get_or_create(
                cart=user_cart, food=item.food
            )
            if not created:
                user_item.quantity += item.quantity
            user_item.save()
        guest_cart.delete()
