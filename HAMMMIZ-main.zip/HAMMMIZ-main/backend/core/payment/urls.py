# urls.py
from django.urls import path
from . import views

app_name = "payment"

urlpatterns = [
    path("cart/", views.CartView.as_view(), name="cart"),
    path("cart/items/add/", views.CartItemAddView.as_view(), name="cart-item-add"),
    path(
        "cart/items/remove/",
        views.CartItemRemoveView.as_view(),
        name="cart-item-remove",
    ),
    path("order/list/", views.OrderListView.as_view(), name="order"),
    # Gateway URLs
    path("gateway/verify/", views.GatewayVerifyView.as_view(), name="gateway-hammmiz"),
]
