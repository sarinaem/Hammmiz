from rest_framework import views, generics, permissions
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .utils import get_or_create_cart
from .models import CartItemModel, PaymentModel, PaymentItemModel
from food.models import FoodModel
from .serializers import CartItemAddSerializer, CartItemRemoveSerializer, PaymentSerializer
from main.serializers import ReservationSerializer
from .serializers import CartSerializer
from .zarinpal_client import ZarinPalSandbox


class CartView(generics.GenericAPIView):
    serializer_class = CartSerializer

    def get(self, request, *args, **kwargs):
        cart = get_or_create_cart(request)
        if not cart:
            return Response({"detail": "Guest token is required."}, status=400)

        serializer = self.get_serializer(cart)
        return Response(serializer.data)


class CartItemAddView(generics.CreateAPIView):
    serializer_class = CartItemAddSerializer

    def create(self, request, *args, **kwargs):
        cart = get_or_create_cart(request)
        if not cart:
            return Response({"detail": "Guest token is required."}, status=400)

        if not cart.hammmiz:
            return Response({"detail": "Hammmiz is required."}, status=400)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        food_id = serializer.validated_data["food_id"]
        quantity = serializer.validated_data["quantity"]

        try:
            food = FoodModel.objects.get(id=food_id)
        except FoodModel.DoesNotExist:
            return Response({"detail": "Food not found."}, status=404)

        item, created = CartItemModel.objects.get_or_create(cart=cart, food=food)
        if created:
            item.quantity = quantity
        else:
            item.quantity += quantity
        item.save()

        return Response({"detail": "Item added."}, status=201)


class CartItemRemoveView(generics.GenericAPIView):
    serializer_class = CartItemRemoveSerializer

    def post(self, request, *args, **kwargs):
        cart = get_or_create_cart(request)
        if not cart:
            return Response({"detail": "Guest token is required."}, status=400)

        if not cart.hammmiz:
            return Response({"detail": "Hammmiz is required."}, status=400)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        food_id = serializer.validated_data["food_id"]

        try:
            food = FoodModel.objects.get(id=food_id)
        except FoodModel.DoesNotExist:
            return Response({"detail": "Food not found."}, status=404)

        cart_item_obj = get_object_or_404(CartItemModel, cart=cart, food=food)
        cart_item_obj.quantity -= 1
        cart_item_obj.save()
        if cart_item_obj.quantity == 0:
            cart_item_obj.delete()

        return Response({"detail": "Item removed."}, status=200)
    

class OrderListView(generics.ListAPIView):
    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return PaymentModel.objects.filter(user=self.request.user, status="successful")


# GatewayVerifyView
class GatewayVerifyView(views.APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        amount = request.data.get("amount")
        authority = request.data.get("authority")

        if not amount or not authority:
            return Response({"detail": "Amount and authority are required."}, status=400)

        zarinpal_client = ZarinPalSandbox()
        response = zarinpal_client.payment_verification(amount, authority)

        if response["data"]["code"] == 100:
            cart = get_or_create_cart(request)
            payment = PaymentModel.objects.create(
                user=request.user,
                authority=authority,
                hammmiz=cart.hammmiz,
                amount=amount,
                status="successful",
                ref_id=response["data"]["ref_id"],
                card_number=response["data"]["card_pan"],
            )
            # Create payment items based on the cart items
            for item in cart.items.all():
                PaymentItemModel.objects.create(
                    payment=payment,
                    food=item.food,
                    quantity=item.quantity,
                    price=item.food.price
                )
            # Clear the cart after successful payment
            cart.delete()
            payment.hammmiz.status = "reserved"
            payment.hammmiz.save()
            return Response({
                "details": response,
                "created_date": payment.created_date.date(),  # Call the method
                "hammmiz": ReservationSerializer(payment.hammmiz).data,
                "items": [  # Serialize items
                    {
                        "food": item.food.id,
                        "quantity": item.quantity,
                        "price": item.price
                    }
                    for item in payment.items.all()
                ]
            }, status=200)
        else:
            return Response({
                "detail": "Payment verification failed.",
                "response_code": response.get("code"),
                "message": response.get("message")
            }, status=400)
