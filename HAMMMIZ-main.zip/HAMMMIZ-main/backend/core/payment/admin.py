from django.contrib import admin
from .models import *

admin.site.register(CartModel)
admin.site.register(CartItemModel)
admin.site.register(PaymentModel)
admin.site.register(PaymentItemModel)
