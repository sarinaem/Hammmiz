from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal
from main.validators import validate_iranian_landline_number


class HammmizModel(models.Model):
    name = models.CharField(max_length=200)
    latitude = models.FloatField()
    longitude = models.FloatField()
    address = models.CharField(max_length=80)
    score = models.DecimalField(
        max_digits=2,
        decimal_places=1,
        validators=[
            MinValueValidator(Decimal("0.0")),
            MaxValueValidator(Decimal("5.0")),
        ],
        default=Decimal("0.0"),
    )
    open_at = models.TimeField()
    close_at = models.TimeField()
    metro_name = models.CharField(max_length=200)
    distance_from_metro = models.PositiveSmallIntegerField()
    parking_name = models.CharField(max_length=200)
    distance_from_parking = models.PositiveSmallIntegerField()
    landline_number = models.CharField(
        max_length=11, validators=[validate_iranian_landline_number]
    )
    image = models.ImageField(upload_to="hammmiz_images/")
    hammmiz_map = models.ImageField(upload_to="hammmiz_map_images/")

    def __str__(self):
        return self.name


class TableModel(models.Model):
    hammmiz = models.ForeignKey(HammmizModel, on_delete=models.CASCADE)
    table_number = models.PositiveIntegerField(unique=True)
    number_of_seats = models.PositiveIntegerField()
    table_image = models.ImageField(upload_to="table_images/")
    table_image_weight = models.FloatField()
    table_image_height = models.FloatField()
    X = models.FloatField()
    Y = models.FloatField()
    weight = models.FloatField()
    height = models.FloatField()

    def __str__(self):
        return f"Table {self.table_number} at {self.hammmiz.name}"


class ReservationModel(models.Model):

    table = models.ForeignKey(
        TableModel, on_delete=models.CASCADE, related_name="table"
    )
    # date = jmodels.jDateField()
    date = models.DateField()
    started_time = models.TimeField()
    ended_time = models.TimeField()
    extra_seats = models.BooleanField(default=False)
    extra_adult_seats = models.PositiveIntegerField(default=0)
    extra_child_seats = models.PositiveIntegerField(default=0)
    birthday_service = models.BooleanField(default=False)
    reception_service = models.BooleanField(default=False)
    glass = models.PositiveIntegerField(default=0)
    spoon_and_fork = models.PositiveIntegerField(default=0)
    serving_plate = models.PositiveIntegerField(default=0)
    status = models.CharField(
        max_length=20,
        choices=[
            ("pending", "Pending"),
            ("reserved", "Reserved"),
            ("available", "Available"),
        ],
        default="pending",
    )
    final_price = models.DecimalField(
        default=None, max_digits=10, decimal_places=0, null=True, blank=True
    )

    def __str__(self):
        return f"{self.status} Reservation at {self.table.hammmiz.name} - {self.table.table_number}"