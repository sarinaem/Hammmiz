from django.contrib import admin
from .models import HammmizModel, TableModel, ReservationModel

admin.site.register(HammmizModel)
admin.site.register(TableModel)
admin.site.register(ReservationModel)
