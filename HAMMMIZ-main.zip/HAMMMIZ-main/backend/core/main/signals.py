from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import ReservationModel
from .tasks import delete_if_pending


@receiver(post_save, sender=ReservationModel)
def schedule_deletion(sender, instance, created, **kwargs):
    if created:
        delete_if_pending.apply_async((instance.id,), countdown=500)
