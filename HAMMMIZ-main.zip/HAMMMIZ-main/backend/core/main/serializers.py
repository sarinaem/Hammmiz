from rest_framework import serializers
from .models import HammmizModel, ReservationModel, TableModel


class TableAvailabilitySerializer(serializers.ModelSerializer):
    reservation_status = serializers.SerializerMethodField(read_only=True)
    hammmiz = serializers.StringRelatedField()

    class Meta:
        model = TableModel
        fields = [
            "id",
            "hammmiz",
            "table_number",
            "number_of_seats",
            "table_image",
            "table_image_weight",
            "table_image_height",
            "reservation_status",
            "X",
            "Y",
            "weight",
            "height",
        ]

    def get_reservation_status(self, obj):
        date = self.context.get("date")
        start_time = self.context.get("start_time")
        end_time = self.context.get("end_time")

        if date and start_time and end_time:
            reservation = ReservationModel.objects.filter(
                table=obj,
                date=date,
                started_time__lt=end_time,
                ended_time__gt=start_time,
            ).first()
            return reservation.status if reservation else "available"
        return "unknown"


class HammmizSerializer(serializers.ModelSerializer):
    class Meta:
        model = HammmizModel
        fields = "__all__"


class ReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReservationModel
        fields = "__all__"
