from celery import shared_task
from .models import ReservationModel


@shared_task
def delete_if_pending(obj_id):
    try:
        obj = ReservationModel.objects.get(id=obj_id)
        if obj.status == "pending":
            obj.delete()
    except ReservationModel.DoesNotExist:
        pass
