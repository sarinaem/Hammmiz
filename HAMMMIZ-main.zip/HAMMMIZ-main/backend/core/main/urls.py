from django.urls import path
from . import views

app_name = "main"

urlpatterns = [
    path("test/", views.TestView.as_view(), name="test"),
    path(
        "hammmiz_locations/",
        views.HammmizLocations.as_view(),
        name="hammmiz-locations",
    ),
    path("reserve_table/", views.ReserveTable.as_view(), name="reserver-table"),
    path(
        "check_hammmiz/<str:hammmiz_name>/<str:date>/<str:start_time>/<str:end_time>",
        views.CheckHammmiz.as_view(),
        name="check-table",
    ),
]
