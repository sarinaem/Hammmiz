from rest_framework.views import APIView
from rest_framework.generics import ListAPIView, CreateAPIView
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter
from rest_framework.exceptions import ValidationError
from .models import HammmizModel, ReservationModel, TableModel
from payment.utils import get_or_create_cart
from .serializers import (
    HammmizSerializer,
    ReservationSerializer,
    TableAvailabilitySerializer,
)


class TestView(APIView):
    """
    Test view to check if the API is working.
    """

    def get(self, request):
        return Response({"message": "API is working!!"})


class HammmizLocations(ListAPIView):
    queryset = HammmizModel.objects.all()
    serializer_class = HammmizSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter]
    search_fields = ["name"]


class ReserveTable(CreateAPIView):
    queryset = ReservationModel.objects.all()
    serializer_class = ReservationSerializer

    def perform_create(self, serializer):
        table = serializer.validated_data["table"]
        date = serializer.validated_data["date"]
        start_time = serializer.validated_data["started_time"]
        end_time = serializer.validated_data["ended_time"]

        overlapping_reservations = ReservationModel.objects.filter(
            table=table,
            date=date,
            started_time__lt=end_time,
            ended_time__gt=start_time,
        )

        if overlapping_reservations.exists():
            raise ValidationError(
                "This table is already reserved for the selected time range."
            )

        # Save the reservation
        reservation = serializer.save()

        # Get or create cart
        request = self.request
        cart = get_or_create_cart(request)

        if not cart:
            raise ValidationError("Guest token is required to reserve a table.")

        if reservation.status == "pending":
            cart.hammmiz = reservation
            cart.save()
        else:
            return Response({"detail": "Hammmiz is not available."}, status=400)

        return reservation


class CheckHammmiz(ListAPIView):
    serializer_class = TableAvailabilitySerializer

    def get_queryset(self):
        return TableModel.objects.filter(hammmiz__name=self.kwargs["hammmiz_name"])

    def get_serializer_context(self):
        if getattr(self, "swagger_fake_view", False):
            return {}

        return {
            "date": self.kwargs["date"],
            "start_time": self.kwargs["start_time"],
            "end_time": self.kwargs["end_time"],
        }
