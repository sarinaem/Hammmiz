from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken 
from django.contrib.auth import get_user_model
from .models import User, CustomerProfile, RestaurantProfile, PhoneOTP
from .utils import generate_otp, send_sms
from django.utils import timezone
User = get_user_model()

class GetCustomerApiSerializers(serializers.ModelSerializer):
    phone_number = serializers.EmailField(source="user.phone_number", read_only=True)
    id = serializers.IntegerField(source="user.id", read_only=True)

    class Meta:
        model = CustomerProfile
        fields = ["id", "phone_number", "email", "first_name", "last_name", "avatar"]
        

class GetRestaurantApiSerializers(serializers.ModelSerializer):

    class Meta:
        model = RestaurantProfile
        fields = '__all__'


class PhoneNumberSerializer(serializers.Serializer):
    phone_number = serializers.CharField()

    def create(self, validated_data):
        phone = validated_data['phone_number']
        otp_code = generate_otp()
        now = timezone.now()
        
        obj, _ = PhoneOTP.objects.update_or_create(
            phone_number=phone,
            defaults={
                'otp_code': otp_code,
                'created_at': now
            }
        )
        send_sms(phone, otp_code)
        return obj


class VerifyOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    otp_code = serializers.CharField()
    user_type = serializers.ChoiceField(
        choices=[
            ("customer", "Customer"),
            ("restaurant", "Restaurant"),
            ("admin", "Admin"),
        ],
        default="customer",
    )

    def validate(self, data):
        phone_number = data.get('phone_number')
        code = data.get('otp_code')
        user_type = data.get('user_type')

        try:
            otp_obj = PhoneOTP.objects.get(phone_number=phone_number)
        except PhoneOTP.DoesNotExist:
            raise serializers.ValidationError("OTP not found.")

        if otp_obj.is_expired():
            raise serializers.ValidationError("OTP expired.")

        if otp_obj.otp_code != code:
            raise serializers.ValidationError("Incorrect OTP.")
        
        user, _ = User.objects.get_or_create(phone_number=phone_number, user_type=user_type)

        data['user'] = user
        return data