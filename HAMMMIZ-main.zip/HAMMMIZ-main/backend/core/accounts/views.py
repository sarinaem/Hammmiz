from django.shortcuts import get_object_or_404
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from payment.utils import merge_guest_cart_to_user
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import (
    GetCustomerApiSerializers,
    GetRestaurantApiSerializers,
    PhoneNumberSerializer,
    VerifyOTPSerializer,
)
from accounts.models import CustomerProfile

class GetMeApiView(generics.RetrieveUpdateAPIView):
    permission_classes = [IsAuthenticated]
    queryset = CustomerProfile.objects.all()

    def get_serializer_class(self):
        user = self.request.user
        if user.user_type == "restaurant":
            return GetRestaurantApiSerializers
        return GetCustomerApiSerializers

    def get_object(self):
        queryset = self.get_queryset()
        obj = get_object_or_404(queryset, user=self.request.user)
        return obj
    

class SendOTPView(APIView):
    def post(self, request):
        serializer = PhoneNumberSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "OTP sent successfully."})
        return Response(serializer.errors, status=400)


class VerifyOTPView(APIView):
    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            guest_token = request.headers.get("X-Guest-Token")
            if guest_token:
                merge_guest_cart_to_user(guest_token, user)
            refresh = RefreshToken.for_user(user)
            return Response({
                "access": str(refresh.access_token),
                "refresh": str(refresh),
                "id": user.id,
                "phone_number": user.phone_number,
            })
        return Response(serializer.errors, status=400)