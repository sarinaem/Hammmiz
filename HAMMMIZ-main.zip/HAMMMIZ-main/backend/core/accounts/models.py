from django.db import models
from django.contrib.auth.models import (
    AbstractBaseUser,
    BaseUserManager,
    PermissionsMixin,
)
from django.utils.translation import gettext_lazy as _
from django.db.models.signals import post_save
from django.dispatch import receiver
from .validators import validate_iranian_cellphone_number, validate_iranian_landline_number
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal
from django.utils import timezone


class UserManager(BaseUserManager):

    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError(_("The phone_number must be set"))
        user = self.model(phone_number=phone_number, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, phone_number, **extera_fields):
        extera_fields.setdefault("is_staff", True)
        extera_fields.setdefault("is_superuser", True)
        extera_fields.setdefault("is_verified", True)
        extera_fields.setdefault("user_type", "admin")

        if extera_fields.get("is_staff") is not True:
            raise ValueError(_("is_staff must be True"))
        if extera_fields.get("is_superuser") is not True:
            raise ValueError(_("is_superuser must be True"))

        return self.create_user(phone_number, **extera_fields)


class User(AbstractBaseUser, PermissionsMixin):
    phone_number = models.CharField(
        max_length=12,
        validators=[validate_iranian_cellphone_number],
        unique=True,
    )
    user_type = models.CharField(
        max_length=20,
        choices=[
            ("customer", "Customer"),
            ("restaurant", "Restaurant"),
            ("admin", "Admin"),
        ],
        default="customer",
    )
    is_superuser = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    created_date = models.DateField(auto_now_add=True)
    USERNAME_FIELD = "phone_number"
    objects = UserManager()

    def __str__(self):
        return self.phone_number


class CustomerProfile(models.Model):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="user_profile"
    )
    avatar = models.ImageField(blank=True, null=True)
    first_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    email = models.EmailField(blank=True)

    def __str__(self):
        return self.user.phone_number
    
class RestaurantProfile(models.Model):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="restaurant_profile"
    )
    business_type = models.ManyToManyField("food.FoodCategoryModel", blank=True, related_name="restaurants")
    food_type = models.ManyToManyField("food.FoodTypeModel", blank=True, related_name="restaurants")
    name = models.CharField(max_length=50, blank=True, null=True)
    restaurant_name = models.CharField(max_length=50, blank=True, null=True)
    address = models.CharField(max_length=300, blank=True, null=True)
    city = models.CharField(max_length=50, blank=True, null=True)
    Postal_code = models.CharField(max_length=10, blank=True, null=True)
    lattitude = models.FloatField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)
    card_number = models.CharField(max_length=16, blank=True, null=True)
    shaba_number = models.CharField(max_length=24, blank=True, null=True)
    id_card = models.ImageField(upload_to="restaurant_id_cards/", blank=True, null=True)
    business_license = models.ImageField(upload_to="restaurant_business_licenses/", blank=True, null=True)
    landline_number = models.CharField(
        max_length=11, validators=[validate_iranian_landline_number], 
        blank=True, null=True
    )
    min_delivery_time = models.PositiveSmallIntegerField(blank=True, null=True)
    max_delivery_time = models.PositiveSmallIntegerField(blank=True, null=True)
    working_from = models.TimeField(blank=True, null=True)
    working_till = models.TimeField(blank=True, null=True)
    restaurant_banner = models.ImageField(upload_to="restaurant_banners", blank=True, null=True)
    restaurant_logo = models.ImageField(upload_to="restaurant_logos", blank=True, null=True)
    score = models.DecimalField(
        max_digits=2,
        decimal_places=1,
        validators=[
            MinValueValidator(Decimal("0.0")),
            MaxValueValidator(Decimal("5.0")),
        ], 
        default=Decimal("0.0"),
        blank=True, null=True
    )
    hammmiz_validation = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.phone_number
    
class PhoneOTP(models.Model):
    phone_number = models.CharField(max_length=15, unique=True)
    otp_code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_expired(self):
        return timezone.now() > self.created_at + timezone.timedelta(minutes=2)

    def __str__(self):
        return f"{self.phone_number} - {self.otp_code}"


@receiver(post_save, sender=User)
def profile_saver(sender, instance, created, **kwargs):
    if created:
        if instance.user_type == "restaurant":
            RestaurantProfile.objects.create(user=instance)
        else:
            CustomerProfile.objects.create(user=instance)