
import random

def generate_otp():
    return str(random.randint(100000, 999999))

def send_sms(phone_number, otp_code):
    # Replace this with your SMS API call
    print(f"Send SMS to {phone_number} with code: {otp_code}")