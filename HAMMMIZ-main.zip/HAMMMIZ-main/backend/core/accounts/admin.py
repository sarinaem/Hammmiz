from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomerProfile, RestaurantProfile, PhoneOTP
from django.contrib.auth import get_user_model

User = get_user_model()


class CustomUserAdmin(UserAdmin):
    """
    Custom admin panel for user management with add and change forms plus password
    """

    model = User
    list_display = ("id", "phone_number", "is_superuser", "is_verified")
    list_filter = ("phone_number", "is_superuser", "is_verified")
    searching_fields = ("phone_number",)
    ordering = ("phone_number",)
    fieldsets = (
        (
            "Authentication",
            {
                "fields": ("phone_number",),
            },
        ),
        (
            "permissions",
            {
                "fields": (
                    "is_staff",
                    "is_superuser",
                    "is_verified",
                ),
                "user type": (
                    "user_type",
                ),
            },
        ),
        (
            "group permissions",
            {
                "fields": (
                    "groups",
                    "user_permissions",
                    "user_type",
                ),
            },
        ),
        (
            "important date",
            {
                "fields": ("last_login",),
            },
        ),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "phone_number",
                    "is_staff",
                    "is_superuser",
                    "is_verified",
                ),
            },
        ),
    )


admin.site.register(CustomerProfile)
admin.site.register(RestaurantProfile)
admin.site.register(PhoneOTP)
admin.site.register(User, CustomUserAdmin)
