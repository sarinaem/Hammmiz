from django.urls import path
from . import views

app_name = "accounts"

urlpatterns = [
    # User urls
    path("get/me/", views.GetMeApiView.as_view(), name="get_me"),
    path('auth/send-otp/', views.SendOTPView.as_view(), name='send_otp'),
    path('auth/verify-otp/', views.VerifyOTPView.as_view(), name='verify_otp'),
]
